---
title: "Cocciones"
wordpress_id: 16062
content_type: page
status: "publish"
published_at: "2024-08-21T13:47:27"
modified_at: "2024-11-27T20:01:14"
slug: "cocciones"
source_url: "https://fresco.art/cocciones/"
---
# Cocciones

###### **Cocción de piezas de cerámica**

La nave es un nuevo espacio multidisciplinar que se encuentra a pie de calle en el barrio de Carabanchel, reinventando el local de una antigua imprenta.

Puedes cocer tus piezas de cerámica en nuestro horno de hasta 1300º/ 100L de capacidad. Horno completo o por volumen de piezas sueltas. Alta y baja temperatura. Escríbenos y te enviamos la información.

¡Ven a conocernos!

![](https://fresco.art/wp-content/uploads/2024/11/horno_frescalanave3-300x225.jpeg)

![](https://fresco.art/wp-content/uploads/2024/11/Horno_frescalanave_6-300x225.jpeg)

![](https://fresco.art/wp-content/uploads/2024/11/4Horno_frescalanave-300x225.jpeg)

![](https://fresco.art/wp-content/uploads/2024/11/horno_frescalanave2-300x225.jpeg)

![](https://fresco.art/wp-content/uploads/2024/11/horno_frescalanave1-300x225.jpeg)

![](https://fresco.art/wp-content/uploads/2024/06/E39A2410-60D1-4C3D-8DD1-B4B9A5B7C58A-2-240x300.jpg)

![](https://fresco.art/wp-content/uploads/2024/08/Cowork_fresca.lanave10-300x225.jpeg)

![](https://fresco.art/wp-content/uploads/2024/08/Cocciones_frescalanave-300x225.png)

![](https://fresco.art/wp-content/uploads/2024/08/Cowork_fresca.lanave5-300x225.jpeg)

![](https://fresco.art/wp-content/uploads/2024/05/fresca_la-nave_fresco.art22-300x225.jpeg)

![](https://fresco.art/wp-content/uploads/2024/08/Cocciones_fresca.lanave12-300x225.jpeg)

##### Suscríbete a nuestra newsletter
