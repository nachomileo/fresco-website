---
title: "Talleres"
wordpress_id: 11356
content_type: page
status: "publish"
published_at: "2022-05-25T09:04:42"
modified_at: "2022-05-29T18:36:09"
slug: "talleres22"
source_url: "https://fresco.art/talleres22/"
---
# Talleres

#### Talleres

[

![Nicolás Romero Escalada](https://fresco.art/wp-content/uploads/2022/09/NaturalezaMuerta_Pili-scaled.jpg)

Nicolás Romero Escalada

Naturalezas Muertas como medio para representar la cultura pop

](https://fresco.art/wp-content/uploads/2022/09/NaturalezaMuerta_Pili-scaled.jpg)[

![Ignacio Rivas](https://fresco.art/wp-content/uploads/2022/06/Ignacio_Rivas_collage_fresco.art-25.png)

Ignacio Rivas

Caos, intuición y juego. Técnicas de Collage analógico.

](https://fresco.art/wp-content/uploads/2022/06/Ignacio_Rivas_collage_fresco.art-25.png)[

![Santiago Picatoste](https://fresco.art/wp-content/uploads/2022/06/Santiago-Picatoste_fresco.art_-scaled.jpg)

Santiago Picatoste

Fábrica de deseos. “Jam Session” en la nave industrial. Segunda Edición

](https://fresco.art/wp-content/uploads/2022/06/Santiago-Picatoste_fresco.art_-scaled.jpg)[

![Pablo Merchante](https://fresco.art/wp-content/uploads/2022/06/Taller-PabloMerchante-fresco.art-56-scaled.jpg)

Pablo Merchante

Introducción a lo profundo de la pintura. Del error a lo fortuito. Edición 2

](https://fresco.art/wp-content/uploads/2022/06/Taller-PabloMerchante-fresco.art-56-scaled.jpg)[

![Los Bravú](https://fresco.art/wp-content/uploads/2022/11/Taller-fresco-Los-Bravu-8-scaled.jpg)

Los Bravú

Escenas de un banquete. Festín contemporáneo

](https://fresco.art/wp-content/uploads/2022/11/Taller-fresco-Los-Bravu-8-scaled.jpg)[

![Residencia Artística con Pablo Merchante](https://fresco.art/wp-content/uploads/2022/11/Residencia_Pablo_Merchante_fresco.art_131-1-scaled.jpg)

Residencia Artística con Pablo Merchante

Naturaleza para la pintura. Ritual, vigor e intuición.

](https://fresco.art/wp-content/uploads/2022/11/Residencia_Pablo_Merchante_fresco.art_131-1-scaled.jpg)[

![Movimiento, cuerpo y pintura. Ed II](https://fresco.art/wp-content/uploads/2022/08/Taller-fresco-Movimiento_26-scaled.jpeg)

Movimiento, cuerpo y pintura. Ed II

Movimiento, cuerpo y pintura. La excusa del proceso creativo

](https://fresco.art/wp-content/uploads/2022/08/Taller-fresco-Movimiento_26-scaled.jpeg)[

![Serigrafía contemporánea](https://fresco.art/wp-content/uploads/2023/02/Taller_serigrafia_multiple_editions_fresco_II-4-scaled.jpg)

Serigrafía contemporánea

Revelando las capas de la imagen. Serigrafía artística contemporánea.

](https://fresco.art/wp-content/uploads/2023/02/Taller_serigrafia_multiple_editions_fresco_II-4-scaled.jpg)[

![Rosh](https://fresco.art/wp-content/uploads/2023/02/Taller_Rosh_fresco.art_-scaled.jpg)

Rosh

Lenguaje urbano, digital y pictórico. Juegos para un imaginario visual

](https://fresco.art/wp-content/uploads/2023/02/Taller_Rosh_fresco.art_-scaled.jpg)[

![Justine Menard](https://fresco.art/wp-content/uploads/2023/07/JustineMenard_fresco.art_-scaled.jpg)

Justine Menard

Aire, fuego e intuición. Escultura contemporánea en vidrio

](https://fresco.art/wp-content/uploads/2023/07/JustineMenard_fresco.art_-scaled.jpg)[

![Guido Sarli](https://fresco.art/wp-content/uploads/2023/07/Guido_Sarli_fresco.art_-scaled.jpg)

Guido Sarli

Bailar lo liminal. Laboratorio de movimiento

](https://fresco.art/wp-content/uploads/2023/07/Guido_Sarli_fresco.art_-scaled.jpg)[

![Javier Ruiz](https://fresco.art/wp-content/uploads/2023/07/Javier_Ruiz_fresco.art_1-scaled.jpg)

Javier Ruiz

La pintura tras bambalinas. Retiro de creación interdisciplinar

](https://fresco.art/wp-content/uploads/2023/07/Javier_Ruiz_fresco.art_1-scaled.jpg)[

![Catalina Romero](https://fresco.art/wp-content/uploads/2023/10/Fotografiadeobra_Catalina_Romero-scaled.jpeg)

Catalina Romero

Cómo fotografiar obras de arte

](https://fresco.art/wp-content/uploads/2023/10/Fotografiadeobra_Catalina_Romero-scaled.jpeg)[

![Justine Menard](https://fresco.art/wp-content/uploads/2023/11/IMG_5971-scaled.jpeg)

Justine Menard

Aire, fuego e intuición. Escultura contemporánea en vidrio. Ed II

](https://fresco.art/wp-content/uploads/2023/11/IMG_5971-scaled.jpeg)[

![Nacho Martín Silva](https://fresco.art/wp-content/uploads/2023/12/fresca-la-nave_fresco.art2_-scaled.jpeg)

Nacho Martín Silva

Relatos fragmentados. La dialéctica entre la abstracción y la figuración

](https://fresco.art/wp-content/uploads/2023/12/fresca-la-nave_fresco.art2_-scaled.jpeg)
