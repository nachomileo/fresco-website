---
title: "Mentorías"
wordpress_id: 15777
content_type: page
status: "publish"
published_at: "2024-06-25T11:01:17"
modified_at: "2025-04-14T15:00:18"
slug: "asesoramiento"
source_url: "https://fresco.art/asesoramiento/"
---
# Mentorías

###### **Asesoramiento y apoyo curatorial**

Diseñamos espacios de asesoramiento individual brindando soporte curatorial para la investigación, producción y exposición de proyectos dentro del pensamiento contemporáneo.

Contamos con el apoyo de profesionales para poder hacer de este asesoramiento un trabajo en equipo dinámico y fructífero.

Cuéntanos lo que necesitas y pensamos una propuesta. Existen planes a corto y mediano plazo.

-
-

![](https://fresco.art/wp-content/uploads/2025/04/Cowork-300x225.jpg)

[**](https://fresco.art/wp-content/uploads/2025/04/Cowork-scaled.jpg)

-

![](https://fresco.art/wp-content/uploads/2025/01/Bendita-la-mesa-2024-8-300x225.jpeg)

[**](https://fresco.art/wp-content/uploads/2025/01/Bendita-la-mesa-2024-8-scaled.jpeg)

##### Suscríbete a nuestra newsletter
