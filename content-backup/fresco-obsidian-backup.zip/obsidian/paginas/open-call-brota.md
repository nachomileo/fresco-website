---
title: "Open Call Brota"
wordpress_id: 16314
content_type: page
status: "publish"
published_at: "2024-11-11T16:01:03"
modified_at: "2025-09-21T22:30:29"
slug: "open-call-brota"
source_url: "https://fresco.art/open-call-brota/"
---
# Open Call Brota

Proyecto seleccionado: ¿Qué es el campo? / No sé qué es el campo de Julia Alfaro

Exposición proyecto final, septiembre 2025 en Fresca. La nave:

-
-

![](https://fresco.art/wp-content/uploads/2025/09/15-225x300.jpg)

-

![](https://fresco.art/wp-content/uploads/2025/09/13-240x300.jpg)

-

![](https://fresco.art/wp-content/uploads/2025/09/21-300x225.jpg)

-

![](https://fresco.art/wp-content/uploads/2025/09/11092025_SO_2288-200x300.jpg)

-

![](https://fresco.art/wp-content/uploads/2025/09/17-200x300.jpg)

-

![](https://fresco.art/wp-content/uploads/2025/09/11092025_SO_2290-300x200.jpg)

-

![](https://fresco.art/wp-content/uploads/2025/09/20-300x225.jpg)

-

![](https://fresco.art/wp-content/uploads/2025/09/7-300x200.jpg)

-

![](https://fresco.art/wp-content/uploads/2025/09/18-200x300.jpg)

-

![](https://fresco.art/wp-content/uploads/2025/09/12.png)

-

![](https://fresco.art/wp-content/uploads/2025/09/9-300x200.jpg)

-

![](https://fresco.art/wp-content/uploads/2025/09/2-200x300.jpg)

-

![](https://fresco.art/wp-content/uploads/2025/09/14-240x300.jpg)

-

![](https://fresco.art/wp-content/uploads/2025/09/4-200x300.jpg)

###

### **Open Call Brota 2025**

#### **febrero – junio 2025, Madrid.**

CONVOCATORIA CERRADA

Proyecto seleccionado: «*¿Qué es el campo? / No sé qué es el campo» de Julia Alfaro *

###### **Convocatoria abierta para la investigación, experimentación y producción de proyectos cerámicos en  fresca. La nave  **

Abierta la convocatoria para un espacio de trabajo en nuestro taller de cerámica durante 3 meses, con posibilidad de extensión.

Open call: Presentación de proyectos hasta el **15 de diciembre a las 23:59 h.**

Resultado de la selección: **primera quincena de enero 2025.**

Duración: **desde febrero a junio de 2025.**

Jornada de puertas abiertas: **mayo 2025.**

Exposición individual: **septiembre 2025.**

Brota es una convocatoria abierta para artistas que estén buscando un espacio para investigar, desarrollar y producir un proyecto de cerámica durante 3 meses en Fresca. la nave, en el barrio de Carabanchel, Madrid.

Impulsamos Brota para dar lugar a aquellas ideas que por falta de espacio o medios idóneos no pueden desarrollarse. Comenzamos en esta primera edición seleccionando un proyecto. Tienes tiempo hasta el 15 de diciembre 2024 para enviar la propuesta.

###### **Fechas importantes:**

- Open call: 13-11 al 15-12-2024

- Anuncio proyecto seleccionado: mediados de enero 2025

- Duración: febrero a abril 2025

###### **¿Qué ofrecemos?**

Espacio totalmente equipado y acompañamiento para investigar y producir un proyecto cerámico durante 3 meses, con posibilidad de exponerlo.

STUDIO SPACE

Espacio flexible para la experimentación, investigación y la producción de un proyecto de cerámica contemporánea, en un espacio compartido de 110 m2. Se invita a trabajar con autonomía, encontrando espacios tanto para la concentración y trabajo introspectivo, como para el diálogo y puesta en común. El horario es flexible aunque concertado. Se dispone de horno de 100 lts. de alta temperatura, estantería, torno, laminadora, herramientas, mesas de trabajo, cocina, zona de relax. No incluye materiales ni cocciones.

ACOMPAÑAMIENTO

Seguimiento y apoyo, tanto a nivel técnico como narrativo y poético del proyecto.

RED

Ambiente colaborativo entre artistas que comparten el taller y/o que pasan por la nave.

PROGRAMA & INSPO

Visita a otros talleres del barrio, estudios de artistas, exposiciones, acceso a la biblioteca de la nave.

DIFUSIÓN

Comunicación de los avances de tu proyecto en redes.

EXPOSICIÓN

Posibilidad de compartir tu proceso en jornadas de puertas abiertas o exposición individual. Este punto se valorará en función a lo que necesite el proyecto.

###### **¿A quién está dirigida?**

La convocatoria es para artistas/ceramistas que tengan un proyecto cerámico a desarrollar en un taller profesional. Se valorarán proyectos comprometidos con la materialidad, que tengan una narrativa dentro del pensamiento contemporáneo, abiertos al diálogo y a la experimentación.

###### **¿Cómo aplicar?**

Los proyectos deberán enviarse en un único pdf al correo **brota@fresco.art** con el asunto “Brota 2025”.

El documento debe contener:

1. Datos personales (Nombre completo, fecha y lugar de nacimiento, correo, teléfono). Web y redes sociales.

1. Statement (Breves líneas sobre la intencionalidad de tu trabajo)

1. CV y Portfolio (Una selección de lo que consideres clave para esta convocatoria)

1. Proyecto (Cuéntanos cuál es el proyecto que quieres investigar y producir en la nave durante los 3 meses).

1. Carta de motivación: Nos encantaría saber por qué crees que Fresca. la nave es el espacio idóneo para desarrollar tu proyecto.

No se aceptarán solicitudes que no incluyan la información requerida.

Al enviar la propuesta confirma que se aceptan las bases y condiciones manifestadas en este documento.

###### **Protección de datos**

1. “De acuerdo con la normativa de protección de datos vigente (RGPD 2016/679 y LOPD 3/2018) le informamos que los datos personales que Usted nos proporciona, con el fin de gestionar la participación en el marco de esta convocatoria, son incorporados a un tratamiento de datos personales cuyo responsable del tratamiento es FRESCA, PINTURA Y BARRO, S.L.L. Los datos se conservarán de forma que se permita la identificación de los interesados durante el tiempo estrictamente necesario para la presente participación en la convocatoria realizada que es la finalidad del presente tratamiento, pudiendo conservarse por periodos más largos de tiempo, siempre que se traten exclusivamente con fines de archivo en interés público, ya sea para la investigación científica o histórica o para fines estadísticos, con las medidas técnicas y organizativas adecuadas. La base jurídica del tratamiento es el interés legitimo del Responsable del tratamiento, conforme a lo previsto en el artículo 6.1.f) del RGPD y lo datos personales no serán objeto de cesión ni transferencia a terceros. Las personas interesadas tienen derecho a acceder a sus datos personales, así como a solicitar la rectificación de los datos inexactos o, en su caso, solicitar su supresión, además de los otros derechos contemplados en los artículo 15 a 22 del citado Reglamento. Puede contactar con el Responsable, bien por teléfono en el número  o bien mediante correo electrónico [brota@fresco.art](mailto:brenda@fresco.art) para cualquier cuestión relacionada con la protección de datos personales de los participantes.

1. La presentación de proyectos de investigación artística en el marco de esta convocatoria implicará la presunción de la autoría, siendo responsabilidad de quien haya presentado el proyecto toda reclamación eventual que pudiese surgir”

###### **Contacto**

brota@fresco.art

Salvador Alonso 12. Carabanchel, Madrid.

¿Qué es el campo? / No sé qué es el campo

**

Julia Alfaro

#####

>

Durante mi residencia en La nave estoy pudiendo desarrollar y pensar Qué es el campo. Trabajando paralelamente en distintos procesos. Como distintos acercamientos a una misma pregunta.

Qué es el campo / No sé qué es el campo es una investigación que nace de la pregunta que Rafa, el cámara que nos acompañaba en la residencia de Alumbra, lanzó un día. Una pregunta breve y directa que sin embargo sembró una sensación de duda, ajenidad y culpa latente en mi sentir castellanomanchego.

Con el deseo de explorar y tomar como respuesta válida esos sentimientos, investigo la relación entre cacharro, cuerpo y paisaje. Un triángulo que nos lleva a cuestiones como el desarraigo, la extracción y la identidad.

Cerámica y ruralidad son los dos ejes principales de este proceso, lo que me lleva a reflexionar sobre la alfarería, la artesanía y la tradición cacharrera. Sin embargo, hablar exclusivamente de alfarería supone limitar el desarrollo de la cerámica contemporánea en Castilla-La Mancha. Por ello, trato de ampliar el sentido del material, explorando su fisicidad y las emociones que evoca. Me interesa la mirada mágica hacia territorios, cuerpos, materias primas. Preguntas como ¿cómo se siente un paisaje deshabitado? ¿qué forma tiene el desarraigo? ¿qué forma desearía tener el barro? guían esta investigación, impregnada de una sensación de desarraigo y culpa vinculada al territorio.

Comencé haciendo una serie de cuencos hechos en torno usando distintas tierras locales de nuestra geografía. Aunque de dimensiones parecidas, experimento con materias primas minerales u orgánicas. Utilizo el cuenco (forma básica, primigenia en todos los asentamientos) como excusa para performar un paisaje en la sala de exposiciones. La posibilidad de contener una imagen en movimiento, un paisaje asincrónico.

Paralelamente utilizo el pellizco como una manera de reclamarme. Pensando en Walter Benjamin cuando dice que habitar significa dejar huella. El pellizco como la unidad mínima de significado en un diálogo entre el barro y el cuerpo. La promesa de que hubo alguien ahí.

Estos meses de residencia suponen no solo un espacio de trabajo, sino un espacio de acompañamiento y sostén en los procesos de creación.

Artista residente de Brota 2025

-
-

![](https://fresco.art/wp-content/uploads/2025/04/Cowork-300x225.jpg)

-

![](https://fresco.art/wp-content/uploads/2025/04/Brota-300x225.jpg)

-

![](https://fresco.art/wp-content/uploads/2025/04/IMG_0905-2-225x300.jpg)

-

![](https://fresco.art/wp-content/uploads/2025/04/IMG_0916-2-225x300.jpg)

-

![](https://fresco.art/wp-content/uploads/2025/04/IMG_1595-225x300.jpg)

-

![](https://fresco.art/wp-content/uploads/2025/04/IMG_1608-2-247x300.jpg)

-

![](https://fresco.art/wp-content/uploads/2025/04/IMG_1636-225x300.jpg)

-

![](https://fresco.art/wp-content/uploads/2025/01/Ser-en-una-grieta-179x300.png)

-

![](https://fresco.art/wp-content/uploads/2025/04/IMG_1693-300x225.jpg)

-

![](https://fresco.art/wp-content/uploads/2025/04/IMG_1753-300x225.jpg)

-

![](https://fresco.art/wp-content/uploads/2025/04/IMG_1929-300x225.jpg)

-

![](https://fresco.art/wp-content/uploads/2025/04/IMG_1870-225x300.jpg)

-

![](https://fresco.art/wp-content/uploads/2025/04/IMG_1811-225x300.jpg)

-

![](https://fresco.art/wp-content/uploads/2025/04/IMG_1510-300x225.jpg)

##### Suscríbete a nuestra newsletter
