---
title: "fresca. La nave"
wordpress_id: 15489
content_type: page
status: "publish"
published_at: "2024-02-15T09:30:31"
modified_at: "2026-02-21T11:21:10"
slug: "lanave2"
source_url: "https://fresco.art/lanave2/"
---
# fresca. La nave

###### **Espacio para la creación contemporánea en Carabanchel**

Taller de pintura y cerámica dirigido por Brenda Ranieri & fresco.art.

Fresca. La nave es un espacio multidisciplinar que se encuentra a pie de calle en el barrio de Carabanchel, reinventando el local de una antigua imprenta. En 110 m2 se dispone un amplio taller de pintura y cerámica totalmente equipados para compartir con artistas visuales y ceramistas de trabajo autónomo.

Bajo un programa curatorial diseñado por fresco.art, desarrollamos propuestas de experimentación e investigación entre los intersticios del arte y la educación para promover el pensamiento contemporáneo. Se trata a de un programa de mediación diseñado para fomentar, acompañar y potenciar el proceso creativo.

[

![](https://fresco.art/wp-content/uploads/2024/11/Fresca-la-nave-2-225x300.png)

](https://fresco.art/wp-content/uploads/2024/11/Fresca-la-nave-2.png)[

![](https://fresco.art/wp-content/uploads/2024/11/Fresca-la-nave-1-225x300.png)

](https://fresco.art/wp-content/uploads/2024/11/Fresca-la-nave-1.png)[

![](https://fresco.art/wp-content/uploads/2024/11/Fresca-la-nave-5-225x300.png)

](https://fresco.art/wp-content/uploads/2024/11/Fresca-la-nave-5.png)[

![](https://fresco.art/wp-content/uploads/2024/11/Fresca-la-nave-4-225x300.png)

](https://fresco.art/wp-content/uploads/2024/11/Fresca-la-nave-4.png)[

![](https://fresco.art/wp-content/uploads/2024/11/Fresca-la-nave-3-225x300.png)

](https://fresco.art/wp-content/uploads/2024/11/Fresca-la-nave-3.png)[

![](https://fresco.art/wp-content/uploads/2024/03/fresca-la-nave_fresco.art1_-300x225.jpeg)

](https://fresco.art/wp-content/uploads/2024/03/fresca-la-nave_fresco.art1_-scaled.jpeg)[

![](https://fresco.art/wp-content/uploads/2024/06/Brenda-Ranieri_fresca.La-nave-300x225.jpeg)

](https://fresco.art/wp-content/uploads/2024/06/Brenda-Ranieri_fresca.La-nave-scaled.jpeg)[

![](https://fresco.art/wp-content/uploads/2024/05/fresca_la-nave_fresco.art26-240x300.jpg)

](https://fresco.art/wp-content/uploads/2024/05/fresca_la-nave_fresco.art26.jpg)[

![](https://fresco.art/wp-content/uploads/2023/12/fresca-la-nave_fresco.art2_-300x225.jpeg)

](https://fresco.art/wp-content/uploads/2023/12/fresca-la-nave_fresco.art2_-scaled.jpeg)[

![](https://fresco.art/wp-content/uploads/2024/06/Brenda-Ranieri_fresca.-La-nave--169x300.jpg)

](https://fresco.art/wp-content/uploads/2024/06/Brenda-Ranieri_fresca.-La-nave-.jpg)[

![](https://fresco.art/wp-content/uploads/2024/03/fresca.-La-nave-5-225x300.jpeg)

](https://fresco.art/wp-content/uploads/2024/03/fresca.-La-nave-5-scaled.jpeg)[

![](https://fresco.art/wp-content/uploads/2024/03/fresca.-La-nave-17-225x300.jpeg)

](https://fresco.art/wp-content/uploads/2024/03/fresca.-La-nave-17-scaled.jpeg)[

![](https://fresco.art/wp-content/uploads/2024/05/fresca_la-nave_fresco.art22-300x225.jpeg)

](https://fresco.art/wp-content/uploads/2024/05/fresca_la-nave_fresco.art22-scaled.jpeg)[

![](https://fresco.art/wp-content/uploads/2024/04/fresca.-la-nave_5-300x225.jpeg)

](https://fresco.art/wp-content/uploads/2024/04/fresca.-la-nave_5-scaled.jpeg)[

![](https://fresco.art/wp-content/uploads/2023/12/fresca-la-nave_fresco.art9_-300x225.jpeg)

](https://fresco.art/wp-content/uploads/2023/12/fresca-la-nave_fresco.art9_-scaled.jpeg)[

![](https://fresco.art/wp-content/uploads/2024/03/fresca-la-nave_fresco.art4_-300x225.jpeg)

](https://fresco.art/wp-content/uploads/2024/03/fresca-la-nave_fresco.art4_-scaled.jpeg)[

![](https://fresco.art/wp-content/uploads/2024/05/fresca_la-nave_fresco.art28-240x300.jpg)

](https://fresco.art/wp-content/uploads/2024/05/fresca_la-nave_fresco.art28.jpg)[

![](https://fresco.art/wp-content/uploads/2024/04/fresca.-la-nave_3-300x225.jpeg)

](https://fresco.art/wp-content/uploads/2024/04/fresca.-la-nave_3-scaled.jpeg)[

![](https://fresco.art/wp-content/uploads/2024/05/fresca_la-nave_fresco.art24-218x300.jpeg)

](https://fresco.art/wp-content/uploads/2024/05/fresca_la-nave_fresco.art24-scaled.jpeg)[

![](https://fresco.art/wp-content/uploads/2024/11/Bendita-la-mesa-2024-8-300x225.jpeg)

](https://fresco.art/wp-content/uploads/2024/11/Bendita-la-mesa-2024-8-scaled.jpeg)

##### Suscríbete a nuestra newsletter
