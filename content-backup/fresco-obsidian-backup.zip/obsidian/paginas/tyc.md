---
title: "Términos y Condiciones"
wordpress_id: 3
content_type: page
status: "publish"
published_at: "2022-05-21T15:17:25"
modified_at: "2025-08-11T11:11:47"
slug: "tyc"
source_url: "https://fresco.art/tyc/"
---
# Términos y Condiciones

**fresco.art**
Términos y Condiciones
2025, agosto

Te damos la bienvenida al acuerdo de Condiciones de uso del fresco. A los efectos de este acuerdo, «Sitio» se refiere al sitio web de la Compañía, al que se puede acceder en fresco.art. «Servicio» se refiere a los servicios de la Compañía a los que se accede a través del Sitio, en los que los usuarios pueden registrarse en cursos de talleres de arte presenciales u online. Los términos «nosotros», «nos» y «nuestro» se refieren a la Compañía. «Estudiante» se refiere al usted, como usuario de nuestro Sitio o de nuestro Servicio.

Los siguientes Términos de uso se aplican cuando ve o usa el Servicio a través de nuestro sitio web ubicado en fresco.art

Por favor revise los siguientes términos cuidadosamente. Al acceder o utilizar el Servicio, usted manifiesta su aceptación de estos Términos de uso. Si no acepta estar sujeto a estos Términos de uso en su totalidad, no podrá acceder ni utilizar el Servicio.

##### SOBRE EL SERVICIO

El Servicio le permite registrarse en talleres y convocatorias de arte presenciales.

###### Tasas

El estudiante se inscribe solo una vez que se procesa el pago y solo después de que la solicitud se procesa con éxito y fresco.art envía una confirmación de inscripción. No se pueden dar reducciones de tarifas, reembolsos, créditos o lecciones adicionales por entrada tardía o ausencia o salida anticipada de un curso. Los reembolsos aprobados solo pueden ser realizados por nosotros. Fresco.art se reserva el derecho de hacer ajustes de tarifas como resultado de cambios en los tipos de cambio o impuestos legales.

###### Cancelación

Puede cancelar su contrato con fresco.art en cualquier momento por escrito mediante entrega registrada. Las tarifas de cancelación para pagos completos son las siguientes:

- 15 días antes del comienzo del curso: 50% (Se reembolsa la mitad)

- 7 días antes del comienzo del curso: 100% (No hay reembolso)

En ausencia de un aviso de cancelación por escrito, fresco.art retendrá las tarifas del curso en su totalidad.
Si decide no utilizar los servicios reservados con fresco.art después del comienzo de su curso, no se le reembolsarán las tarifas.

Las tarifas de cancelación para pagos de reserva son las siguientes:

- En los casos en los que el estudiante ha pagado sólo la reserva, no habrá devolución ni transferencia de dicha reserva.

###### Excepciones COVID-19:

Si el evento se cancela o el estudiante no puede asistir por razones provocadas por la pandemia COVID-19, fresco.art procederá a devolver la tarifas u ofrecer otra experiencia a cambio. El estudiante deberá demostrar que no ha podido asistir debido a causas relacionadas con la COVID-19.

###### Cancelación por fresco.art

Si los cursos no llegaran a realizarse por falta de aforo, 7 días antes del comienzo del curso se informará a los estudiantes de la posible cancelación del mismo y procederemos a devolver el importe íntegro de la reserva de plaza.
Si un estudiante no cumple con los términos y condiciones de la empresa, fresco.art se reserva el derecho de cancelar el contrato. Las tarifas del curso no serán reembolsadas.

###### Asesoramientos

Este servicio no cuenta con reembolso alguno.

###### Garantía

Si encuentra algún fallo en los servicios proporcionados por fresco.art, debe declarar su reclamo a fresco.art durante el período del curso. Cualquier reclamo realizado después del final de nuestros servicios no será reconocido. En caso de una reclamación justificada, nos reservamos el derecho de realizar un reembolso adecuado.

###### Seguros

fresco.art no será responsable de ninguna pérdida, daño, enfermedad o lesión de personas o bienes causados. Es el estudiante quien tiene la responsabilidad de contratar un seguro personal contra todos los riesgos, incluida la imposibilidad de asistir o continuar un curso y el seguro para el pago de gastos médicos.

###### Circunstancias inevitables

Será una condición fundamental del contrato entre fresco.art que tampoco seremos responsables ante el estudiante en el caso de que cualquier servicio contratado sea imposible de suministrar debido a una disputa industrial o cualquier otra causa fuera de su control.

###### Protección de datos Open Call Brota

1. “De acuerdo con la normativa de protección de datos vigente (RGPD 2016/679 y LOPD 3/2018) le informamos que los datos personales que Usted nos proporciona, con el fin de gestionar la participación en el marco de esta convocatoria, son incorporados a un tratamiento de datos personales cuyo responsable del tratamiento es FRESCA, PINTURA Y BARRO, S.L.L. Los datos se conservarán de forma que se permita la identificación de los interesados durante el tiempo estrictamente necesario para la presente participación en la convocatoria realizada que es la finalidad del presente tratamiento, pudiendo conservarse por periodos más largos de tiempo, siempre que se traten exclusivamente con fines de archivo en interés público, ya sea para la investigación científica o histórica o para fines estadísticos, con las medidas técnicas y organizativas adecuadas. La base jurídica del tratamiento es el interés legitimo del Responsable del tratamiento, conforme a lo previsto en el artículo 6.1.f) del RGPD y lo datos personales no serán objeto de cesión ni transferencia a terceros. Las personas interesadas tienen derecho a acceder a sus datos personales, así como a solicitar la rectificación de los datos inexactos o, en su caso, solicitar su supresión, además de los otros derechos contemplados en los artículo 15 a 22 del citado Reglamento. Puede contactar con el Responsable, bien por teléfono en el número  o bien mediante correo electrónico [brota@fresco.art](mailto:brenda@fresco.art) para cualquier cuestión relacionada con la protección de datos personales de los participantes.

1. La presentación de proyectos de investigación artística en el marco de esta convocatoria implicará la presunción de la autoría, siendo responsabilidad de quien haya presentado el proyecto toda reclamación eventual que pudiese surgir”

###### Validez de las condiciones

Estas condiciones de inscripción son válidas a partir del 18 de octubre de 2021 y están sujetas a la legislación europea.

###### Aceptación de las condiciones

Al inscribirse en cualquiera de nuestros talleres y convocatorias, las personas aceptan las condiciones.

#####

##### POLÍTICA DE PRIVACIDAD

Razón Social: FRESCA, PINTURA Y BARRO, S.L.L. (en adelante, la “Empresa” o el “Responsable”).
CIF: B56631989
Domicilio: Calle Salvador Alonso, 12 – 28019 – Madrid – MADRID
Email para comunicaciones en materia de Protección de datos: info@fresco.art

La Compañía respeta la privacidad de los usuarios en sus Servicios. Los datos
personales serán recopilados y procesados por un sistema automatizado con el objetivo de mantener sus datos de contacto de acuerdo con el Reglamento (UE) 2016/679 del Parlamento Europeo y la Ley Orgánica 3/2018 de 5 de diciembre, de Protección de Datos Personales y garantía de los derechos digitales. Dichos datos personales serán tratados como confidenciales y no serán compartidos con terceros ajenos al grupo fresco.art. Tiene derecho a solicitar el acceso a sus datos personales guardados por fresco.art para los fines de dicho servicio y solicitar que se modifique, rectifique o elimine los mismo, de conformidad con lo previsto en el artículo 15 a 21 del RGPD. Para este efecto, comuníquese con fresco.art enviando un correo electrónico a la siguiente dirección: info@fresco.art.
En dicha notificación deberá proceder a identificarse debidamente por medio de D.N.I. si actúa en nombre propio o, en caso de actuar por medio de representante, que se aporte documento que acredite debidamente dicha representación acompañado de D.N.I. del representado. En el asunto deberá indicarse “Ejercicio de Derechos Protección de Datos”

###### ¿Qué información recopilamos y qué hacemos con ella?

Cuando se inscribe como estudiante o suscriptor en nuestro sitio, como parte del proceso de inscripción, recopilamos la información personal que nos proporciona, como su nombre y dirección de correo electrónico.
Marketing por correo electrónico: podemos enviarle correos electrónicos sobre nuestro sitio y cursos relacionados, contenido del curso, progreso de su curso y otras actualizaciones. También podemos usar su correo electrónico para informarle sobre cambios en el curso, encuestarlo sobre su uso o recabar su opinión.

###### ¿Cómo se obtiene mi consentimiento?

Cuando nos proporciona información personal para convertirse en un aprendiz en nuestro sitio, participar de una convocatoria, realizar una compra o participar en el curso, implica que acepta que la recopilemos y la usemos solo por ese motivo específico. Si solicitamos su información personal por un motivo secundario, como marketing, le pediremos directamente su consentimiento expreso, dándole la oportunidad de manifestar su negativa a continuar recibiendo este tipo información comercial, de conformidad con lo establecido en la Ley 34/2002, de 11 de julio, de Servicios de la Sociedad de la Información y del Comercio Electrónico.

###### ¿Cómo retiro mi consentimiento?

Informarle que el consentimiento prestado es revocable en cualquier momento y sin necesidad de ninguna justificación. Si después de optar, cambia de opinión, puede retirar su consentimiento para que nos comuniquemos con usted, para la recopilación, uso o divulgación continua de su información, en cualquier momento, pulsando “desuscribirse” que aparece al pie del correo enviado.

###### Divulgación

No se prevén cesiones de datos ni transferencias internacionales de sus datos, a excepción de las autorizadas por la legislación fiscal, mercantil y de telecomunicaciones, así como en aquellos casos en los que una autoridad judicial nos lo requiera.

###### Pago

Si realiza una compra en nuestro sitio, utilizamos un procesador de pagos de terceros, como Stripe, Bizum o Paypal. Los pagos se cifran a través del Estándar de seguridad de datos de la industria de tarjetas de pago (PCI-DSS). Los datos de su transacción de compra se almacenan solo el tiempo necesario para completar su transacción de compra.
Todas las pasarelas de pago directo se adhieren a los estándares establecidos por PCI-DSS administrados por el PCI Security Standards Council, que es un esfuerzo conjunto de marcas como Visa, MasterCard, American Express y Discover.
Los requisitos de PCI-DSS ayudan a garantizar el manejo seguro de la información de la tarjeta de crédito por parte de nuestro sitio y los cursos relacionados y sus proveedores de servicios.

###### Servicios de terceros

En general, los proveedores de terceros que utilizamos solo recopilarán, usarán y divulgarán su información en la medida necesaria para permitirles realizar los servicios que nos brindan. Sin embargo, ciertos proveedores de servicios de terceros, como las pasarelas de pago y otros procesadores de transacciones de pago, tienen sus propias políticas de privacidad con respecto a la información que debemos proporcionarles para sus transacciones relacionadas con la compra. Para estos proveedores, le recomendamos que lea sus políticas de privacidad para que pueda comprender la forma en que estos proveedores manejarán su información personal. Ciertos proveedores pueden estar ubicados o tener instalaciones ubicadas en una jurisdicción diferente a la suya o la nuestra. Si elige continuar con una transacción que involucra los servicios de un proveedor de servicios externo, su información puede estar sujeta a las leyes de las jurisdicciones en las que se encuentra ese proveedor de servicios o sus instalaciones. Como ejemplo, si se encuentra en Canadá y su transacción es procesada por una pasarela de pago ubicada en los Estados Unidos, entonces su información personal utilizada para completar esa transacción puede estar sujeta a divulgación bajo la legislación de los Estados Unidos, incluida la Ley Patriot. Una vez que abandona nuestro sitio web del curso o es redirigido a un sitio web o aplicación de un tercero, ya no se rige por esta Política de privacidad ni por los Términos de servicio de nuestro sitio web.

###### Seguridad

Para proteger su información personal, tomamos precauciones razonables y seguimos las mejores prácticas de la industria para asegurarnos de que no se pierda, use, acceda, divulgue, altere o destruya de manera inapropiada. Si nos proporciona la información de su tarjeta de crédito, la información se cifra utilizando la tecnología de capa de conexión segura (SSL) y se almacena con un cifrado AES-256. Aunque ningún método de transmisión a través de Internet o almacenamiento electrónico es 100% seguro, seguimos todos los requisitos de PCI-DSS e implementamos estándares adicionales de la industria generalmente aceptados.

Dentro de nuestro compromiso por garantizar la seguridad y confidencialidad de sus datos de carácter personal, le informamos que se han adoptado las medidas de índole técnica y organizativas necesarias para garantizar la seguridad de los datos de carácter personal y evitar su alteración, pérdida, tratamiento o acceso no autorizado, habida cuenta del estado de la tecnología, la naturaleza de los datos almacenados y los riesgos a que estén expuestos, según el Art. 32 del RGPD EU 679/2016.

###### Cookies

Recopilamos cookies o tecnologías de seguimiento similares. Esto significa información que el servidor de nuestro sitio web transfiere a su computadora. Esta información se puede utilizar para rastrear su sesión en nuestro sitio web. Las cookies también se pueden utilizar para personalizar el contenido de nuestro sitio web para usted como individuo. Si está utilizando uno de los navegadores web comunes de Internet, puede configurar su navegador para que le avise cuando reciba una cookie o para negarle el acceso a su computadora. Utilizamos cookies para reconocer su dispositivo y brindarle una experiencia personalizada. También utilizamos cookies para atribuir visitas a nuestros sitios web a fuentes de terceros y para publicar anuncios dirigidos de Google, Facebook, Instagram y otros proveedores de terceros. Optar por no participar: puede optar por no recibir anuncios dirigidos a través de proveedores externos específicos visitando la página de exclusión de Digital Advertising Alliance. También podemos utilizar métodos de seguimiento automatizados en nuestros sitios web, en comunicaciones con usted y en nuestros productos y servicios, para medir el rendimiento y la participación

###### Herramientas de análisis web

Podemos usar herramientas de análisis web integradas en el sitio web de fresco.art para medir y recopilar información de sesión anónima.

###### Edad de consentimiento

Al usar este sitio, usted declara que tiene al menos la mayoría de edad en su estado o provincia de residencia, o que tiene la mayoría de edad en su estado o provincia de residencia.

###### Plazo de conservación de sus datos

Conservaremos sus datos personales desde que nos dé su consentimiento hasta que lo revoque o bien solicite la limitación del tratamiento. En tales casos, mantendremos sus datos de manera bloqueada durante los plazos legalmente exigidos.

###### Cambios a esta Política de privacidad

Nos reservamos el derecho de modificar esta política de privacidad en cualquier momento, por lo tanto, revísela con frecuencia. Los cambios y aclaraciones entrarán en vigencia inmediatamente después de su publicación en el sitio web. Si hacemos cambios materiales a esta política, le notificaremos aquí que se ha actualizado, para que sepa qué información recopilamos, cómo la usamos y bajo qué circunstancias, si corresponde, usamos y / o divulgamos eso.
Si nuestro sitio o curso se adquiere o se fusiona con otra compañía, su información puede transferirse a los nuevos propietarios para que podamos continuar vendiéndole productos.

##### PREGUNTAS E INFORMACIÓN DE CONTACTO

Si desea acceder, corregir, modificar o eliminar cualquier información personal que tengamos sobre usted, o hacernos cualquier consulta, escríbenos a info@fresco.art.
