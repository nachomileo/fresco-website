---
title: "Co work"
wordpress_id: 16036
content_type: page
status: "publish"
published_at: "2024-08-21T13:07:41"
modified_at: "2024-11-27T19:45:58"
slug: "cowork"
source_url: "https://fresco.art/cowork/"
---
# Co work

###### **Co working**

La nave es un nuevo espacio multidisciplinar que se encuentra a pie de calle en el barrio de Carabanchel, reinventando el local de una antigua imprenta.

En 110 m2 se dispone un amplio taller de pintura y cerámica totalmente equipados para compartir con artistas visuales y ceramistas de trabajo autónomo.

¡Ven a conocernos!

![](https://fresco.art/wp-content/uploads/2024/11/Fresca-la-nave-2-225x300.png)

![](https://fresco.art/wp-content/uploads/2024/11/Fresca-la-nave-4-225x300.png)

![](https://fresco.art/wp-content/uploads/2024/11/Coworking-300x225.jpeg)

![](https://fresco.art/wp-content/uploads/2024/08/Dump-de-mayo-en-la-nave-Proyectos-en-produccion-Residencia-En-barrio-expo-colectiva-y-las-mejores-compis-de-taller-2-240x300.jpg)

![](https://fresco.art/wp-content/uploads/2024/11/Fresca-la-nave-5-225x300.png)

![](https://fresco.art/wp-content/uploads/2024/11/Fresca-la-nave-3-225x300.png)

![](https://fresco.art/wp-content/uploads/2024/08/Cowork_fresca.lanave6-300x225.jpeg)

![](https://fresco.art/wp-content/uploads/2024/08/fresca.lanave_fresco.art_carabanchel1-1-300x225.jpeg)

![](https://fresco.art/wp-content/uploads/2024/11/Fresca-la-nave-1-225x300.png)

![](https://fresco.art/wp-content/uploads/2024/08/Dump-de-mayo-en-la-nave-Proyectos-en-produccion-Residencia-En-barrio-expo-colectiva-y-las-mejores-compis-de-taller-1-240x300.jpg)

![](https://fresco.art/wp-content/uploads/2024/06/IMG_1322-300x225.jpeg)

![](https://fresco.art/wp-content/uploads/2024/08/Cowork_fresca.lanave9-300x225.jpeg)

![](https://fresco.art/wp-content/uploads/2024/08/Cowork_fresca-lanave13-300x225.jpeg)

![](https://fresco.art/wp-content/uploads/2024/08/Cowork_fresca.lanave11-300x225.jpeg)

![](https://fresco.art/wp-content/uploads/2024/05/fresca_la-nave_fresco.art26-240x300.jpg)

![](https://fresco.art/wp-content/uploads/2024/08/Cowork_fresca.lanave5-300x225.jpeg)

![](https://fresco.art/wp-content/uploads/2024/08/Cowork_fresca.lanave10-300x225.jpeg)

![](https://fresco.art/wp-content/uploads/2024/06/IMG_1328-300x225.jpeg)

##### Suscríbete a nuestra newsletter
