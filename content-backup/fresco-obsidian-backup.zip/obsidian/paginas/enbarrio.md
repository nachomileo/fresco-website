---
title: "Open Call Residencia"
wordpress_id: 15549
content_type: page
status: "publish"
published_at: "2024-03-17T16:14:54"
modified_at: "2024-07-10T11:56:15"
slug: "enbarrio"
source_url: "https://fresco.art/enbarrio/"
---
# Open Call Residencia

##### **📢​ OPEN CALL en barrio | mayo 2024, Madrid.**

###### **Residencia de producción artística en Carabanchel, comisariada por Alejandra Diaz-Guerra y organizada por fresco.art, fresca. La nave y herbáceas 🤝🏼​ **

En barrio es una residencia de investigación y producción que busca generar diálogos de aproximación entre lo urbano y la naturaleza en el contexto del barrio de Carabanchel. Durante dos semanas, del 10 al 24 de mayo de 2024, lxs artistas seleccionadxs tendrán a su disposición materiales de investigación y producción artística en el espacio fresca. La nave, situado en Carabanchel, para desarrollar un proyecto acorde con el marco conceptual de la residencia y que verá la luz en forma de exposición final colectiva donde se expondrán las obras producidas junto a sus respectivos procesos de investigación.

La convocatoria está dirigida a artistas plásticos y visuales en activo de cualquier nacionalidad y edad que tengan interés en la investigación artística con una perspectiva crítica sobre las implicaciones de la naturaleza en el contexto urbano del barrio de Carabanchel. Entre otras disciplinas, y por las posibilidades del espacio de producción, se valorarán positivamente las propuestas cuyos formatos incluyan cerámica, instalación, escultura, pintura, textil y/o fotografía.

###### **Artistas seleccionadas:**

YESE ASTARLOA

MARÍA ESTEVE

FEDERICA FURBELLI

ANDY LUENGO

EVA ORTIZ SUÁREZ

CAROLINA MARCOS RIBERA

###### **Fechas:**

- Open call: 17-03 al 17-04-2024

- Anuncio artistas seleccionadxs: 22-04-2024

- Investigación y producción artística: 10 al 25-05-2024

- Exposición colectiva + Open studio: 24-05-2024

###### **¿Qué ofrecemos?**

Espacio y acompañamiento para producir un proyecto de investigación, relacionado al tema propuesto, y tener la posibilidad de exponerlo.

2 semanas de investigación y producción artística con:

- Equipamiento y materiales

- Mentorías, seguimiento y mediación de la investigación y producción artística

- Talleres, charlas y actividades especiales

- Encuentro con artistas y profesionales del ámbito de la cultura y el arte

- Visitas a estudios y espacios de creación contemporánea en el contexto de Carabanchel y alrededores.

- Difusión y promoción del trabajo realizado durante la residencia a través de diferentes medios digitales.

- Presentación pública y exposición colectiva.

- Documentación fotográfica profesional de la exposición colectiva.

- Un fanzine editado y publicado a modo de memoria con la explicación del proyecto y la intervención de cada artista.

- Exposición colectiva + Open Studio.

La exposición colectiva fue el resultado de la residencia artística En barrio en la que durante dos semanas las artistas Yese Astarloa, María Esteve, Federica Furbelli, Andy Luengo, Eva Ortiz y Carolina Marcos Ribera han investigado y producido obra en el espacio fresca. La nave en torno al concepto de la naturaleza como elemento vertebrador y discursivo de la identidad del barrio de Carabanchel.

En el contexto de la gentrificación y las nuevas formas de habitar el territorio que han redefinido al barrio, lo natural persiste como un elemento pasivo de coexistencia. En el período de residencia, mediante un proceso de reflexión critica y producción artística, las artistas han abordado diversos temas como la resiliencia de la maleza, los pozos de agua que conectan el subsuelo del barrio con la superficie, las texturas urbanas o las redes que conforman y van tejiendo la vida en comunidad.

La residencia contó con un programa de mediación diseñado para las artistas residentes con agenda con actividades dentro y fuera de la nave pensadas para apoyar los procesos de creación de cada una. Talleres, derivas, charlas, actividades con la comunidad, visitas a estudios del barrio y exposiciones.

Un proyecto comisariado por Alejandra Díaz-Guerra Acedo en diálogo con Brenda Ranieri, directora y coordinadora de la residencia.

###### **CONVOCATORIA FINALIZADA.**

Consulta Bases y Condiciones

-
-

![](https://fresco.art/wp-content/uploads/2024/06/Exposicion-en-barrio-fresca.-la-nave_1-81-300x225.jpeg)

-

![](https://fresco.art/wp-content/uploads/2024/06/Residencia-en-barrio_fresco.art4_-169x300.jpeg)

-

![](https://fresco.art/wp-content/uploads/2024/06/Exposicion-en-barrio-fresca.-la-nave_1-78-300x225.jpeg)

-

![](https://fresco.art/wp-content/uploads/2024/06/Residencia-en-barrio_fresco.art5_-300x225.jpeg)

-

![](https://fresco.art/wp-content/uploads/2024/06/Puertas-abiertas-212x300.png)

-

![](https://fresco.art/wp-content/uploads/2024/06/Exposicion-en-barrio-fresca.-la-nave_1-76-300x225.jpeg)

-

![](https://fresco.art/wp-content/uploads/2024/06/Exposicion-en-barrio-fresca.-la-nave_1-70-300x225.jpeg)

-

![](https://fresco.art/wp-content/uploads/2024/06/Residencia-en-barrio_fresco.art3_-300x225.jpeg)

-

![](https://fresco.art/wp-content/uploads/2024/06/Exposicion-en-barrio-fresca.-la-nave_1-74-300x225.jpeg)

-

![](https://fresco.art/wp-content/uploads/2024/06/Programa-212x300.png)

-

![](https://fresco.art/wp-content/uploads/2024/06/Residencia-en-barrio_fresco.art10-300x225.jpeg)

-

![](https://fresco.art/wp-content/uploads/2024/06/Residencia-en-barrio_fresco.art2_-300x225.jpeg)

-

![](https://fresco.art/wp-content/uploads/2024/06/Residencia-en-barrio_fresco.art6_-300x225.jpeg)

-

![](https://fresco.art/wp-content/uploads/2024/06/Residencia-en-barrio_fresco.art7_-300x225.jpeg)

-

![](https://fresco.art/wp-content/uploads/2024/06/Residencia-en-barrio_fresco.art8_-300x225.jpeg)

-

![](https://fresco.art/wp-content/uploads/2024/06/Residencia-en-barrio_fresco.art9_-300x225.jpeg)

-

![](https://fresco.art/wp-content/uploads/2024/06/IMG_0989-169x300.jpeg)

-

![](https://fresco.art/wp-content/uploads/2024/06/cartel-Expo-212x300.png)

-

![](https://fresco.art/wp-content/uploads/2024/06/Exposicion-en-barrio-fresca.-la-nave_1-300x225.jpeg)

-

![](https://fresco.art/wp-content/uploads/2024/06/IMG_1121-300x225.jpeg)

-

![](https://fresco.art/wp-content/uploads/2024/06/IMG_7897-300x200.jpg)

-

![](https://fresco.art/wp-content/uploads/2024/06/IMG_7902-300x200.jpg)

-

![](https://fresco.art/wp-content/uploads/2024/06/Exposicion-en-barrio-fresca.-la-nave_1-2-300x225.jpeg)

-

![](https://fresco.art/wp-content/uploads/2024/06/Exposicion-en-barrio-fresca.-la-nave_1-85-225x300.png)

-

![](https://fresco.art/wp-content/uploads/2024/06/Exposicion-en-barrio-fresca.-la-nave_1-67-300x225.jpeg)

-

![](https://fresco.art/wp-content/uploads/2024/06/Exposicion-en-barrio-fresca.-la-nave_1-6-300x225.jpeg)

-

![](https://fresco.art/wp-content/uploads/2024/06/d811c8d4-fd25-45f8-8e01-5fe5a9b48a33-225x300.jpg)

-

![](https://fresco.art/wp-content/uploads/2024/06/IMG_9012-300x225.jpeg)

##### Suscríbete a nuestra newsletter
