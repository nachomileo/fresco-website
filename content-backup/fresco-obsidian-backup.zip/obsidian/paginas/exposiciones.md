---
title: "Exposiciones"
wordpress_id: 16083
content_type: page
status: "publish"
published_at: "2024-08-21T14:02:53"
modified_at: "2024-11-27T20:03:16"
slug: "exposiciones"
source_url: "https://fresco.art/exposiciones/"
---
# Exposiciones

###### **Openings**

La nave cuenta con espacio expositivo para tu proyecto artístico. Además podemos brindarte apoyo curatorial y seguimiento. Visítanos y vemos posibilidades.

[

![](https://fresco.art/wp-content/uploads/2024/06/Exposicion-en-barrio-fresca.-la-nave_1-300x225.jpeg)

](https://fresco.art/wp-content/uploads/2024/06/Exposicion-en-barrio-fresca.-la-nave_1-scaled.jpeg)[

![](https://fresco.art/wp-content/uploads/2024/08/Exposiciones_fresca.lanave-300x225.png)

](https://fresco.art/wp-content/uploads/2024/08/Exposiciones_fresca.lanave.png)[

![](https://fresco.art/wp-content/uploads/2024/06/Exposicion-en-barrio-fresca.-la-nave_1-85-225x300.png)

](https://fresco.art/wp-content/uploads/2024/06/Exposicion-en-barrio-fresca.-la-nave_1-85.png)[

![](https://fresco.art/wp-content/uploads/2024/08/Exposicion-en-barrio-fresca.-la-nave_1-4-225x300.jpeg)

](https://fresco.art/wp-content/uploads/2024/08/Exposicion-en-barrio-fresca.-la-nave_1-4-scaled.jpeg)[

![](https://fresco.art/wp-content/uploads/2024/06/d811c8d4-fd25-45f8-8e01-5fe5a9b48a33-225x300.jpg)

](https://fresco.art/wp-content/uploads/2024/06/d811c8d4-fd25-45f8-8e01-5fe5a9b48a33.jpg)[

![](https://fresco.art/wp-content/uploads/2024/08/Exposicion-en-barrio-fresca.-la-nave_1-24-300x225.jpeg)

](https://fresco.art/wp-content/uploads/2024/08/Exposicion-en-barrio-fresca.-la-nave_1-24-scaled.jpeg)[

![](https://fresco.art/wp-content/uploads/2024/08/Exposicion-en-barrio-fresca.-la-nave_1-28-300x225.jpeg)

](https://fresco.art/wp-content/uploads/2024/08/Exposicion-en-barrio-fresca.-la-nave_1-28-scaled.jpeg)[

![](https://fresco.art/wp-content/uploads/2024/06/Exposicion-en-barrio-fresca.-la-nave_1-6-300x225.jpeg)

](https://fresco.art/wp-content/uploads/2024/06/Exposicion-en-barrio-fresca.-la-nave_1-6-scaled.jpeg)[

![](https://fresco.art/wp-content/uploads/2024/06/Exposicion-en-barrio-fresca.-la-nave_1-2-300x225.jpeg)

](https://fresco.art/wp-content/uploads/2024/06/Exposicion-en-barrio-fresca.-la-nave_1-2-scaled.jpeg)[

![](https://fresco.art/wp-content/uploads/2024/06/IMG_7897-300x200.jpg)

](https://fresco.art/wp-content/uploads/2024/06/IMG_7897-scaled.jpg)[

![](https://fresco.art/wp-content/uploads/2024/06/IMG_1121-300x225.jpeg)

](https://fresco.art/wp-content/uploads/2024/06/IMG_1121-scaled.jpeg)[

![](https://fresco.art/wp-content/uploads/2024/06/IMG_7902-300x200.jpg)

](https://fresco.art/wp-content/uploads/2024/06/IMG_7902-scaled.jpg)[

![](https://fresco.art/wp-content/uploads/2024/06/Exposicion-en-barrio-fresca.-la-nave_1-67-300x225.jpeg)

](https://fresco.art/wp-content/uploads/2024/06/Exposicion-en-barrio-fresca.-la-nave_1-67-scaled.jpeg)[

![](https://fresco.art/wp-content/uploads/2024/06/Exposicion-en-barrio-fresca.-la-nave_1-78-300x225.jpeg)

](https://fresco.art/wp-content/uploads/2024/06/Exposicion-en-barrio-fresca.-la-nave_1-78-scaled.jpeg)

##### Suscríbete a nuestra newsletter
