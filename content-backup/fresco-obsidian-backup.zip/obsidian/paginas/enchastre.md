---
title: "Enchastre"
wordpress_id: 12288
content_type: page
status: "publish"
published_at: "2022-06-08T23:14:49"
modified_at: "2022-06-29T16:54:45"
slug: "enchastre"
source_url: "https://fresco.art/enchastre/"
---
# Enchastre

*En fresco. nos seduce ese velo de misterio que hay detrás de cada manifestación artística. Nos conmueve la generosidad y valentía de lxs artistas al compartir su mundo interior, para que las personas conozcan otras maneras de percibir la realidad. Vemos a la creación como un acto de amor profundo y por eso estamos aquí para ayudar a potenciarla.

Además notamos que hay una necesidad imperiosa de abordar algunos temas del mundo de la creación, particularmente de los procesos pictóricos. Por ello utilizaremos este medio para profundizar en diferentes temas.*
