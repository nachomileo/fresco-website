---
title: "La nave"
wordpress_id: 16766
content_type: page
status: "publish"
published_at: "2025-04-15T09:44:39"
modified_at: "2026-02-21T11:21:32"
slug: "lanave"
source_url: "https://fresco.art/lanave/"
---
# La nave

Espacio para la creación contemporánea en Madrid

###### Fresco.art es un proyecto vivo y mutante que, desde 2021, impulsa la creatividad a través de propuestas de experimentación e investigación en la intersección entre arte y educación. Desde 2024 cuenta con espacio propio en Carabanchel: *Fresca. la nave*, una antigua imprenta reconvertida en taller para la creación contemporánea, con un programa de propuestas que se renueva cada año.

###### El espacio está dirigido por Brenda Ranieri, artista y ceramista cuya práctica se centra en la investigación matérica, la mezcla de materiales y el trabajo con arcillas locales. Explora la cerámica contemporánea como un lenguaje abierto y un lugar de encuentro entre lo humano y lo no humano.

[Ver el programa](https://descargas.fresco.art)

##### Quiero estar al tanto del programa
