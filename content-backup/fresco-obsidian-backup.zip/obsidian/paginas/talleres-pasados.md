---
title: "Revive la experiencia fresco."
wordpress_id: 14362
content_type: page
status: "publish"
published_at: "2023-06-20T14:16:48"
modified_at: "2024-06-24T05:57:38"
slug: "talleres-pasados"
source_url: "https://fresco.art/talleres-pasados/"
---
# Revive la experiencia fresco.

-
-

Bendita la mesa[fresco](https://fresco.art/author/fresco/)enero 14, 2025abril 26, 2026

[

![](https://fresco.art/wp-content/uploads/2025/01/BODAS-PRIMAVERA-277-scaled.jpg)

Bendita la mesa

Ciclo de cerámica x Brenda Ranieri ft. Cata de vinos naturales x Belén Baldassarre

](https://fresco.art/talleres/bendita-la-mesa/)
-

Carla Souto[fresco](https://fresco.art/author/fresco/)octubre 13, 2024abril 14, 2025

[

![](https://fresco.art/wp-content/uploads/2024/10/stories_2-1.jpg)

Carla Souto

Iniciación al modelado en cera para joyería.

](https://fresco.art/talleres/carla-souto/)
-

Eloy Arribas[fresco](https://fresco.art/author/fresco/)enero 2, 2025abril 14, 2025

[

![](https://fresco.art/wp-content/uploads/2025/01/Taller-Eloy-Arribas_fresco.art_0.jpg)

Eloy Arribas

El collar de Perlas. Eloy Arribas

](https://fresco.art/talleres/eloy-arribas/)
-

Miguel Gómez Losada[fresco](https://fresco.art/author/fresco/)agosto 26, 2024abril 14, 2025

[

![](https://fresco.art/wp-content/uploads/2024/08/Taller-Miguel-Gomez-Losada-scaled.jpg)

Miguel Gómez Losada

Acercamiento a la voz propia: qué pintar y cómo.

](https://fresco.art/talleres/miguel-gomez-losada-24/)
-

Sophie Aguilera[fresco](https://fresco.art/author/fresco/)junio 24, 2024enero 2, 2025

[

![](https://fresco.art/wp-content/uploads/2024/06/SA.jpeg)

Sophie Aguilera

Escultura floral en porcelana

](https://fresco.art/talleres/sophie-aguilera-flores/)
-

Paula Cid Cerezo[fresco](https://fresco.art/author/fresco/)agosto 13, 2024enero 2, 2025

[

![](https://fresco.art/wp-content/uploads/2024/08/IMG_0010-scaled.jpg)

Paula Cid Cerezo

Registros de lo invisible. Grabado contemporáneo

](https://fresco.art/talleres/paula-cid-cerezo/)
-

Julio Galindo[fresco](https://fresco.art/author/fresco/)julio 12, 2024enero 2, 2025

[

![](https://fresco.art/wp-content/uploads/2024/07/IMG_8272-scaled.jpg)

Julio Galindo

Cerámica salvaje. Técnicas de cerámica artística.

](https://fresco.art/talleres/julio-galindo/)
-

Justine Menard[fresco](https://fresco.art/author/fresco/)noviembre 14, 2023junio 24, 2024

[

![](https://fresco.art/wp-content/uploads/2023/11/IMG_5971-scaled.jpeg)

Justine Menard

Aire, fuego e intuición. Escultura contemporánea en vidrio. Ed II

](https://fresco.art/talleres/justine-menard-24/)
-

Nacho Martín Silva[fresco](https://fresco.art/author/fresco/)diciembre 17, 2023junio 24, 2024

[

![](https://fresco.art/wp-content/uploads/2023/12/fresca-la-nave_fresco.art2_-scaled.jpeg)

Nacho Martín Silva

Relatos fragmentados. La dialéctica entre la abstracción y la figuración

](https://fresco.art/talleres/nacho-martin-silva/)
-

Jan Monclús[fresco](https://fresco.art/author/fresco/)enero 9, 2024junio 24, 2024

[

![](https://fresco.art/wp-content/uploads/2024/03/fresca-la-nave_fresco.art1_-scaled.jpeg)

Jan Monclús

Sobre lo absurdo. Nuevas prácticas de la pintura figurativa

](https://fresco.art/talleres/jan-monclus/)
-

Sophie Aguilera[fresco](https://fresco.art/author/fresco/)diciembre 18, 2023junio 24, 2024

[

![](https://fresco.art/wp-content/uploads/2023/12/fresca_la-nave_fresco.art7_-scaled.jpeg)

Sophie Aguilera

Naturalezas muertas. Escenarios contemporáneos en cerámica.

](https://fresco.art/talleres/sophie-aguilera/)
-

Juan Narowé[fresco](https://fresco.art/author/fresco/)julio 17, 2023diciembre 13, 2023

[

![](https://fresco.art/wp-content/uploads/2023/07/IMG_3478-scaled.jpeg)

Juan Narowé

Narrativas del dibujo contemporáneo.

](https://fresco.art/talleres/juan-narowe/)
-

Catalina Romero[fresco](https://fresco.art/author/fresco/)octubre 2, 2023noviembre 7, 2023

[

![](https://fresco.art/wp-content/uploads/2023/10/Fotografiadeobra_Catalina_Romero-scaled.jpeg)

Catalina Romero

Cómo fotografiar obras de arte

](https://fresco.art/talleres/catalina-romero/)
-

Javier Ruiz[fresco](https://fresco.art/author/fresco/)julio 14, 2023octubre 31, 2023

[

![](https://fresco.art/wp-content/uploads/2023/07/Javier_Ruiz_fresco.art_1-scaled.jpg)

Javier Ruiz

La pintura tras bambalinas. Retiro de creación interdisciplinar

](https://fresco.art/talleres/javier-ruiz-23/)
-

Guido Sarli[fresco](https://fresco.art/author/fresco/)julio 13, 2023octubre 31, 2023

[

![](https://fresco.art/wp-content/uploads/2023/07/Guido_Sarli_fresco.art_-scaled.jpg)

Guido Sarli

Bailar lo liminal. Laboratorio de movimiento

](https://fresco.art/talleres/guido-sarli/)
-

Justine Menard[fresco](https://fresco.art/author/fresco/)julio 13, 2023septiembre 29, 2023

[

![](https://fresco.art/wp-content/uploads/2023/07/JustineMenard_fresco.art_-scaled.jpg)

Justine Menard

Aire, fuego e intuición. Escultura contemporánea en vidrio

](https://fresco.art/talleres/justine-menard/)
-

Serigrafía contemporánea[fresco](https://fresco.art/author/fresco/)febrero 21, 2023junio 23, 2023

[

![](https://fresco.art/wp-content/uploads/2023/02/Taller_serigrafia_multiple_editions_fresco_II-4-scaled.jpg)

Serigrafía contemporánea

Revelando las capas de la imagen. Serigrafía artística contemporánea.

](https://fresco.art/talleres/multiple-editions/)
-

Rosh[fresco](https://fresco.art/author/fresco/)febrero 27, 2023junio 23, 2023

[

![](https://fresco.art/wp-content/uploads/2023/02/Taller_Rosh_fresco.art_-scaled.jpg)

Rosh

Lenguaje urbano, digital y pictórico. Juegos para un imaginario visual

](https://fresco.art/talleres/rosh/)
-

Residencia Artística con Pablo Merchante[fresco](https://fresco.art/author/fresco/)noviembre 9, 2022junio 23, 2023

[

![](https://fresco.art/wp-content/uploads/2022/11/Residencia_Pablo_Merchante_fresco.art_131-1-scaled.jpg)

Residencia Artística con Pablo Merchante

Naturaleza para la pintura. Ritual, vigor e intuición.

](https://fresco.art/talleres/residencia-artistica-pablo-merchante/)
-

Ampparito[fresco](https://fresco.art/author/fresco/)noviembre 1, 2022abril 3, 2023

[

![](https://fresco.art/wp-content/uploads/2022/11/fresco-Ampparito_57-scaled.jpg)

Ampparito

Hackear la norma. Intervención Urbana

](https://fresco.art/talleres/ampparito/)
-

Los Bravú[fresco](https://fresco.art/author/fresco/)noviembre 1, 2022abril 3, 2023

[

![](https://fresco.art/wp-content/uploads/2022/11/Taller-fresco-Los-Bravu-8-scaled.jpg)

Los Bravú

Escenas de un banquete. Festín contemporáneo

](https://fresco.art/talleres/los-bravu/)
-

Movimiento, cuerpo y pintura. Ed II[fresco](https://fresco.art/author/fresco/)febrero 1, 2023abril 3, 2023

[

![](https://fresco.art/wp-content/uploads/2022/08/Taller-fresco-Movimiento_26-scaled.jpeg)

Movimiento, cuerpo y pintura. Ed II

Movimiento, cuerpo y pintura. La excusa del proceso creativo

](https://fresco.art/talleres/movimiento-cuerpo-y-pintura-ed-ii/)
-

Pablo Merchante[fresco](https://fresco.art/author/fresco/)noviembre 1, 2022enero 25, 2023

[

![](https://fresco.art/wp-content/uploads/2022/06/Taller-PabloMerchante-fresco.art-56-scaled.jpg)

Pablo Merchante

Introducción a lo profundo de la pintura. Del error a lo fortuito. Edición 2

](https://fresco.art/talleres/pablo-merchante-23/)
-

Ignacio Rivas[fresco](https://fresco.art/author/fresco/)junio 7, 2022noviembre 16, 2022

[

![](https://fresco.art/wp-content/uploads/2022/06/Ignacio_Rivas_collage_fresco.art-25.png)

Ignacio Rivas

Caos, intuición y juego. Técnicas de Collage analógico.

](https://fresco.art/talleres/ignacio_rivas/)
-

Movimiento, cuerpo y pintura[fresco](https://fresco.art/author/fresco/)agosto 19, 2022noviembre 16, 2022

[

![](https://fresco.art/wp-content/uploads/2022/08/Movimiento-cuerpo-y-pintura_fresco.arte_-scaled.jpg)

Movimiento, cuerpo y pintura

Movimiento, cuerpo y pintura. Celebración expresionista.

](https://fresco.art/talleres/movimiento-cuerpo-y-pintura/)
-

Santiago Picatoste[fresco](https://fresco.art/author/fresco/)junio 7, 2022noviembre 9, 2022

[

![](https://fresco.art/wp-content/uploads/2022/06/Santiago-Picatoste_fresco.art_-scaled.jpg)

Santiago Picatoste

Fábrica de deseos. “Jam Session” en la nave industrial. Segunda Edición

](https://fresco.art/talleres/retiro_malaga/)
-

Santiago Picatoste[fresco](https://fresco.art/author/fresco/)junio 2, 2022noviembre 7, 2022

[

![](https://fresco.art/wp-content/uploads/2022/06/6_CursosPasados_Retiro_800x650.jpg)

Santiago Picatoste

Fábrica de deseos. “Jam Session” en la nave industrial. Primera Edición

](https://fresco.art/talleres/santiago-picatoste-2/)
-

Pablo Merchante[fresco](https://fresco.art/author/fresco/)septiembre 9, 2017octubre 20, 2022

[

![](https://fresco.art/wp-content/uploads/2022/06/Taller-Pablo-Merchante_14-scaled.jpg)

Pablo Merchante

Introducción a lo profundo de la pintura. Del error a lo fortuito.

](https://fresco.art/talleres/pablo-merchante/)
-

Mercedes Bellido[fresco](https://fresco.art/author/fresco/)junio 7, 2022octubre 8, 2022

[

![](https://fresco.art/wp-content/uploads/2022/06/Taller_Mercedes_Bellido_fresco.art2_.png)

Mercedes Bellido

Paisajes oníricos. Evocando la belleza oculta.

](https://fresco.art/talleres/mercedes_bellido/)
-

Nicolás Romero Escalada[fresco](https://fresco.art/author/fresco/)junio 7, 2022octubre 5, 2022

[

![](https://fresco.art/wp-content/uploads/2022/09/NaturalezaMuerta_Pili-scaled.jpg)

Nicolás Romero Escalada

Naturalezas Muertas como medio para representar la cultura pop

](https://fresco.art/talleres/nicolas_romero_escalada/)
