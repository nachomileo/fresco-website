---
title: "Programa"
wordpress_id: 15710
content_type: page
status: "publish"
published_at: "2024-06-24T13:04:13"
modified_at: "2024-11-27T19:32:20"
slug: "programa"
source_url: "https://fresco.art/programa/"
---
# Programa

###### **Programa para la creación contemporánea **

fresco. busca potenciar la creatividad y mantenerla viva. Desde su nave en Carabanchel, extiende una propuesta de experiencias artísticas, talleres, residencias y exposiciones donde se busca fomentar el diálogo, el encuentro y la investigación artística.

El programa cuenta con espacios de asesoramiento individual para artistas dentro de nuestras Mentorías y contamos con un apoyo curatorial para la investigación, producción y exposición de proyectos artísticos.

Además, la nave cuenta con el equipamiento necesario y espacio para compartir con artistas visuales y ceramistas de trabajo autónomo.

![](https://fresco.art/wp-content/uploads/2024/06/Residencia-en-barrio_fresco.art1_-300x225.jpeg)

![](https://fresco.art/wp-content/uploads/2024/11/Bendita-la-mesa-2024-40-3-1-225x300.jpeg)

![](https://fresco.art/wp-content/uploads/2024/11/Programa-para-la-creacion-contemporanea_fresco.art2_-300x225.jpeg)

![](https://fresco.art/wp-content/uploads/2024/11/Programa-para-la-creacion-contemporanea_fresco.art1_-300x225.jpeg)

![](https://fresco.art/wp-content/uploads/2024/06/Exposicion-en-barrio-fresca.-la-nave_1-81-300x225.jpeg)

![](https://fresco.art/wp-content/uploads/2023/12/fresca-la-nave_fresco.art2_-300x225.jpeg)

![](https://fresco.art/wp-content/uploads/2024/05/fresca_la-nave_fresco.art26-240x300.jpg)

![](https://fresco.art/wp-content/uploads/2024/06/Residencia-en-barrio_fresco.art4_-169x300.jpeg)

![](https://fresco.art/wp-content/uploads/2024/03/fresca-la-nave_fresco.art1_-300x225.jpeg)

![](https://fresco.art/wp-content/uploads/2024/06/Residencia-en-barrio_fresco.art2_-1-300x225.jpeg)

![](https://fresco.art/wp-content/uploads/2024/11/Programa-para-la-creacion-contemporanea_fresco.art7_-300x225.jpeg)

![](https://fresco.art/wp-content/uploads/2024/11/Programa-para-la-creacion-contemporanea_fresco.art6_-300x225.jpeg)

![](https://fresco.art/wp-content/uploads/2024/05/fresca_la-nave_fresco.art20-300x225.jpeg)

![](https://fresco.art/wp-content/uploads/2024/11/Bendita-la-mesa-2024-42-2-1-300x225.jpeg)

![](https://fresco.art/wp-content/uploads/2024/05/fresca_la-nave_fresco.art24-218x300.jpeg)

![](https://fresco.art/wp-content/uploads/2024/05/fresca_la-nave_fresco.art22-300x225.jpeg)

![](https://fresco.art/wp-content/uploads/2024/11/Programa-para-la-creacion-contemporanea_fresco.art4_-300x225.jpeg)

![](https://fresco.art/wp-content/uploads/2023/12/fresca-la-nave_fresco.art9_-300x225.jpeg)

![](https://fresco.art/wp-content/uploads/2024/05/fresca_la-nave_fresco.art28-240x300.jpg)

![](https://fresco.art/wp-content/uploads/2024/06/2BBBB0FA-21F9-4E9F-AAAE-2D8EABB264D0-240x300.jpg)

![](https://fresco.art/wp-content/uploads/2024/06/Residencia-en-barrio_fresco.art3_-300x225.jpeg)

![](https://fresco.art/wp-content/uploads/2024/06/Residencia-en-barrio_fresco.art5_-300x225.jpeg)

![](https://fresco.art/wp-content/uploads/2024/11/Bendita-la-mesa-2024-42-3-225x300.jpeg)

![](https://fresco.art/wp-content/uploads/2024/06/IMG_1297-300x225.jpeg)

![](https://fresco.art/wp-content/uploads/2024/11/Programa-para-la-creacion-contemporanea_fresco.art3_-300x225.jpeg)

![](https://fresco.art/wp-content/uploads/2024/06/E39A2410-60D1-4C3D-8DD1-B4B9A5B7C58A-240x300.jpg)

![](https://fresco.art/wp-content/uploads/2024/06/IMG_1322-300x225.jpeg)

![](https://fresco.art/wp-content/uploads/2024/06/IMG_1328-300x225.jpeg)

![](https://fresco.art/wp-content/uploads/2024/06/IMG_9012-300x225.jpeg)

![](https://fresco.art/wp-content/uploads/2024/11/Programa-para-la-creacion-contemporanea_fresco.art11-300x225.jpeg)

![](https://fresco.art/wp-content/uploads/2024/11/Programa-para-la-creacion-contemporanea_fresco.art10-300x225.jpeg)

![](https://fresco.art/wp-content/uploads/2024/11/Programa-para-la-creacion-contemporanea_fresco.art9_-300x225.jpeg)

![](https://fresco.art/wp-content/uploads/2024/11/Programa-para-la-creacion-contemporanea_fresco.art5_-300x225.jpeg)

![](https://fresco.art/wp-content/uploads/2024/11/Bendita-la-mesa-2024-41-2-225x300.jpeg)

##### Suscríbete a nuestra newsletter
