---
title: "Voz propia"
wordpress_id: 12618
content_type: post
status: "publish"
published_at: "2022-08-01T09:46:38"
modified_at: "2022-08-01T10:13:36"
slug: "voz-propia"
source_url: "https://fresco.art/voz-propia/"
categories: ["Enchastre"]
tags: ["Miguel Gómez Losada", "aprender a pintar", "arte contemporáneo", "artista", "colores", "identidad de artista", "lenguaje propio", "lenguaje visual", "madrid", "paleta", "pintura", "talleres de pintura", "voz propia"]
---
# Voz propia

Entrega 3 – Enchastre:

![](https://fresco.art/wp-content/uploads/2022/06/Header-1024x400.jpg)

Sobre el lenguaje pictórico personal, la intuición creadora y el conocimiento poético

*En fresco. nos seduce ese velo de misterio que hay detrás de cada manifestación artística. Nos conmueve la generosidad y valentía de lxs artistas al compartir su mundo interior, para que las personas conozcan otras maneras de percibir la realidad. Vemos a la creación como un acto de amor profundo y por eso estamos aquí para ayudar a potenciarla.

Además notamos que hay una necesidad imperiosa de abordar algunos temas del mundo de la creación, particularmente de los procesos pictóricos. Por ello utilizaremos este medio para profundizar en diferentes temas.
*

![](https://fresco.art/wp-content/uploads/2022/07/3-1024x499.jpg)

![](https://fresco.art/wp-content/uploads/2022/07/Miguel_Gomez_Losada_fresco.art_9-1024x654.jpg)

Taller del pintor Miguel Gómez Losada

>

**«El arte no tiene por qué responder a lo que los medios de comunicación consideran actualidad. El arte es un acto de creación y como tal debe hablar primero, iniciando pensamientos, actitudes y una nueva realidad»**

Miguel Gómez Losada

(En su libro «Diario de Pintura», página 35)

**Miguel Gómez Losada** (Córdoba, España, 1967) es un pintor y dibujante español que vive y trabaja en Sevilla. Es licenciado en Bellas Artes en la especialidad de pintura por la Universidad de Sevilla, 1992. Acaba de debutar como escritor con un diario íntimo y personal donde no apreciamos vértigo al lienzo en blanco, y sí confianza en los arrepentimientos y borrados en el cuadro como garantía de ir por el buen camino. Desde 1992, ha expuesto incesantemente su trabajo pictórico en diversas galerías nacionales y ferias, como la Galería Rayuela de Madrid -con la que fue a ARCO (2001), Galería Yusto / Giner con la que fue a Estampa (2018), Galería Álvaro Alcázar de Madrid con “Mi casa” (2020), Galería Birimbao de Sevilla con “España y Portugal” (2021) y “Escandinavia” (2019), “Romanza” en el CAC Málaga (2018), entre algunos de los más recientes.

#### **Acercamiento a la voz propia: qué pintar y cómo**

En mayo del 2022 hemos tenido el privilegio de tener a Miguel Gómez Losada en Madrid impartiendo un taller de pintura compartiendo todo lo aprendido en su trayectoria. Este taller fue una invitación al pensamiento de por qué se pinta y un acercamiento al lenguaje personal. Una edición especial en Madrid inspirada en el ciclo de clases anuales que el pintor imparte en Sevilla en su estudio: una oportunidad única de entrar en contacto con los aprendizajes de tan renombrado pintor, de manera directa y cercana. A través de guías propuestas por el mentor, decidimos cómo pintar y aprendimos a construir una obra de arte a partir de la línea, la forma, el color, la pincelada, y la materia empleada. Y borrar. aprendimos a pintar borrando. Durante todo el curso, disfrutamos de charlas entre los diferentes artistas que acudieron al curso y muchos momentos de inspiración por parte de Miguel, recomendándonos artistas contemporáneos, qué ver y qué leer para enterarnos e cómo se está pintando en la actualidad.

![](https://fresco.art/wp-content/uploads/2022/07/Taller_Miguel_Gomez_Losada_pintura_fresco.art_madrid_4-1024x703.jpg)

![](https://fresco.art/wp-content/uploads/2022/07/Taller_Miguel_Gomez_Losada_pintura_fresco.art_madrid_3-1024x707.jpg)

![](https://fresco.art/wp-content/uploads/2022/07/Taller_Miguel_Gomez_Losada_pintura_fresco.art_madrid_2-1024x1024.jpg)

![](https://fresco.art/wp-content/uploads/2022/07/Taller_Miguel_Gomez_Losada_pintura_fresco.art_madrid-1024x712.jpg)

![](https://fresco.art/wp-content/uploads/2022/07/Taller_Miguel_Gomez_Losada_pintura_fresco.art_alba.-1024x702.jpg)

![](https://fresco.art/wp-content/uploads/2022/07/Taller_Miguel_Gomez_Losada_pintura_fresco.art_mentoria-1024x710.jpg)

![](https://fresco.art/wp-content/uploads/2022/07/Taller_Miguel_Gomez_Losada.jpg)

![](https://fresco.art/wp-content/uploads/2022/07/Taller_Miguel_Gomez_Losada_pintura_fresco.art_madrid_5.jpg)

Así nos lo pasamos en el Taller «Acercamiento a la voz propia: qué pintar y cómo» con Miguel Gómez Losada, mayo 2022

---

#### **Hablemos de inteligencia**

****Tal como sostiene el pintor citado, un buen camino para escuchar la voz propia puede ser evitar seguir los clichés contemporáneos, aquello que está de moda.****

Alejarnos de la tendencia puede abrirnos nuevos caminos, forzándonos a implementar nuestra propia inteligencia para aportar originalidad e innovación.

![](https://fresco.art/wp-content/uploads/2022/07/Joan_Cornella_fresco.art_enchastre.jpeg)

*«Self help». Imagen de [**Joan Cornellà**](https://art.us5.list-manage.com/track/click?u=e9d310075dc515b605aaa6985&id=c823918a96&e=dce4afb302), (Barcelona, 11 de enero de 1981) es un ilustrador e historietista catalán. Sus viñetas se caracterizan por ser una mezcla entre humor absurdo y humor negro. Echa un vistazo en su perfil 🙂*

**¿Sabías que hay 8 tipos de inteligencias?

**(Y que deberíamos aplicarlas a la hora de crear, según la teoría de [Howard Gardner](https://art.us5.list-manage.com/track/click?u=e9d310075dc515b605aaa6985&id=54c3603c24&e=dce4afb302))

**Howard Gardner** (Pensilvania, 1943) es un psicólogo, investigador y profesor de la Universidad de Harvard, conocido  por sus investigaciones en el análisis de las capacidades cognitivas y por haber formulado la *Teoría de las Inteligencias Múltiples.*

****«Teoría de las Inteligencias Múltiples» by Gardner**:**

Según esta teoría, cada ser humano tiene una combinación única de inteligencia y su estimulación facilita que se trabajen al mismo tiempo aptitudes de todo tipo:
desde las habilidades sociales, la creatividad, la motricidad, la toma de decisiones, la lógica o la resolución de problemas. Los 8 tipos son:

1. **La inteligencia musical**: La tienen más desarrollada aquellos que tiene capacidad para tocar instrumentos y componer piezas musicales con facilidad.
1. **Inteligencia corporal y cinestésica**: Hace referencia a las habilidades corporales y motrices que se requieren para manejar herramientas o para expresar ciertas emociones. En ese caso, principalmente destacan los actores, deportistas, cirujanos, performers y artistas.
1. **Inteligencia intrapersonal**: Relacionada con el autocontrol de nuestras emociones, el conocimiento de uno mismo y todos los procesos relacionados, como autoconfianza y automotivación. Quienes tienen esta inteligencia más desarrollada son las personas resilientes.
1. **Inteligencia interpersonal**: Implica la capacidad de establecer relaciones con otras personas, empatía. Suelen tenerla más desarrollada profesores, psicólogos, terapeutas, abogados y pedagogos.
1. **Inteligencia naturalista**: Es la capacidad de categorizar elementos del entorno reconociendo sus diferencias y el modo en el que se relacionan entre sí. Quienes destaquen con este tipo de inteligencia son capaces de adentrarse en entornos naturales, identificar las distintas especies animales y vegetales, aprenderse las características definitorias de cada una y utilizar esta información en su propio beneficio.
1. **Inteligencia lingüístico-verbal**: Se trata de la habilidad para la comunicación oral, para escribir, aprender otros idiomas y también incluye la gestualidad. Quienes mejor dominan esta capacidad de comunicar se supone que son políticos, escritores, poetas, periodistas, actores.
1. **Inteligencia lógico-matemática**: Se vincula a la capacidad para el razonamiento lógico y la resolución de problemas matemáticos.  Los científicos, economistas, académicos, ingenieros y matemáticos suelen destacar en esta clase de inteligencia. La rapidez para solucionar este tipo de problemas determina cuánta inteligencia lógico-matemática tenemos.
1. **Inteligencia visual-espacial**: Esta es la habilidad que nos permite observar el mundo y los objetos desde diferentes perspectivas. Las personas que destacan en este tipo de inteligencia suelen tener capacidades que les permiten idear imágenes mentales, dibujar y detectar detalles, además de un sentido personal por la estética. En esta inteligencia encontramos pintores, fotógrafos, diseñadores, publicistas, arquitectos, creativos. ***Nuestra Favorita 😉***

Basado en artículo de CC/magazine «La teoría de las inteligencias múltiples de Gardner»

#### **La inteligencia se modifica a lo largo de la historia y es una colección de potencialidades que se complementan.**

En resumen: Alimenta tu mente, baby 😉

#### Ningún cerebro funciona igual. Somos únicos. Nuestras vivencias, cómo percibimos el mundo, lo que sentimos y la cultura que consumimos pueden conformar una voz, distinta a todas las que suenan.

![](https://fresco.art/wp-content/uploads/2022/08/Adrian-Ghenie_fresco.art_.jpeg)

Sin título, óleo sobre lienzo, [Adrian Ghenie](https://art.us5.list-manage.com/track/click?u=e9d310075dc515b605aaa6985&id=2f47ece49e&e=dce4afb302) 2019.

---

**Intuición creadora y conocimiento poético**

**Además de alimentarnos de inspiración externa, hay algo que está en nuestro interior e influye en el desarrollo de nuestra voz genuina: la intuición.**

>

**«Cuando la producción de una obra, dejando de obedecer al régimen del placer de los sentidos penetrados por la inteligencia, pasa a someterse al régimen de la intuición creadora o poética, la obra que ha de ser engendrada en la belleza con una perfecta singularidad que hace de ella una suerte de cosmos único.»**

Jacques Maritain

(Libro “La intuición creadora en el arte y en la poesía», página 16)

**Recomendadísimo este libro de lectura densa, pero hermosa y enriquecedora.**
La obra cumbre de Maritain sobre estética: el sentido y significado del arte en las diversas épocas históricas, la compleja relación entre inteligencia y creación artística, el papel del inconsciente en la formación de la obra de arte, la relación entre pintura moderna y belleza, el sentido de la experiencia poética, la música y la magia, la melodía y el ritmo, etc.

**«Intuición creativa y Conocimiento poético» by Meritain**

El **conocimiento poético** es aquel que extraemos de las «intuiciones sensibles», aquello que sentimos sobre la esencia individual de las cosas o de las personas.  La **intuición creativa**, según Maritain, es la actuación que hace posible la elaboración de la composición poética, aquella que misteriosamente transforma el conocimiento poético en poesía. Y esto se produce frecuentemente no como manifestación directa de la conciencia del poeta, sino sutilmente, en el inconsciente.
**Cuando la intuición la trasladamos a una creación, inspiramos a las personas con nuestra forma de ver el mundo, nuestra visión. **

>

*«No soy capaz de distinguir el sentimiento que tengo de la vida, del modo de expresarlo»*

Herni Matisse

y también Paul Cézanne se refería a esta «visión»

>

*«El tiempo y la reflexión, por lo demás, van modificando paulatinamente
nuestra visión hasta que, por último, llegamos a comprender».*

Paul Cézanne

Basado en el libro “La intuición creadora en el arte y en la poesía» de Jacques Maritain

---

Del error a lo fortuito

La intuición es un elemento clave para incorporar el error como una herramienta más de la creación. Artistas como [**Pablo Merchante**](https://art.us5.list-manage.com/track/click?u=e9d310075dc515b605aaa6985&id=bc6e863a3f&e=dce4afb302), son el ejemplo de ello y lo hemos dialogado y comprobado muchísimo en su taller fresco. de junio 2022: [**«Introducción a lo profundo de la pintura. Del error a lo fortuito»**](https://fresco.art/talleres/pablo-merchante/)

>

**“Fuera de recursos conceptuales, mis trabajos buscan ser autónomos y expresar por si mismos los anhelos de un pintor. Las decisiones diarias que se transforman en los errores diarios y la fortuna de decidir fallar y volver a empezar”**

Pablo Merchante

**Pablo Merchante, **1979. Vive y trabaja en Bollullos Par del Condado, un pequeño y bonito pueblo de Huelva. Estudió Bellas Artes en la Universidad de Sevilla y continuó con el Máster en Idea y Producción enfocado en el Arte Contemporáneo en la misma universidad.
Merchante cuenta con numerosos premios y becas y su obra ha sido adquirida por importantes colecciones de arte contemporáneo como Fundación Art -Circle (Eslovenia), Fundación Bogliasco (New York) o Fundación de Valentín de Madariaga.
Sus trabajos han sido expuestos en ferias nacionales e internacionales como Arco en el stand de la Diputación de Huelva o en Just Lx Lisboa con Di Art Gallery o en el Museo Nacional de Arte Moderno de San José (República Dominicana).
Durante su trayectoria, su obra ha sido muy premiada. Algunos de los reconocimientos más actuales son Beca DVD (Daniel Vázquez Díaz) Diputación de Huelva (2020), Segundo Premio Concurso Internacional de Pintura «Manuel Ángeles Ortiz» Universidad de Jaén (2020), Homeless Resident. Void Project Miami (2020-2019), Finalista. XXIII Premio de Pintura BMW en Madrid (2019).

![](https://fresco.art/wp-content/uploads/2022/08/Taller-Pablo-Merchante_4-768x1024.jpg)

![](https://fresco.art/wp-content/uploads/2022/08/Taller-Pablo-Merchante_15-scaled.jpg)

![](https://fresco.art/wp-content/uploads/2022/08/Taller-Pablo-Merchante_14-scaled.jpg)

![](https://fresco.art/wp-content/uploads/2022/08/Taller-Pablo-Merchante_13-scaled.jpg)

![](https://fresco.art/wp-content/uploads/2022/08/Taller-Pablo-Merchante_12-scaled.jpg)

![Taller Pablo Merchante & fresco.art](https://fresco.art/wp-content/uploads/2022/08/Taller-Pablo-Merchante_11-scaled.jpg)

![](https://fresco.art/wp-content/uploads/2022/08/Taller-Pablo-Merchante_2-scaled.jpg)

![](https://fresco.art/wp-content/uploads/2022/08/Taller-Pablo-Merchante_9-2.jpg)

![](https://fresco.art/wp-content/uploads/2022/08/Taller-Pablo-Merchante-2-scaled.jpg)

Algunos momentos del increíble taller con el pintor contemporáneo Pablo Merchante: **[«Introducción a lo profundo de la pintura. Del error a lo fortuito»](https://fresco.art/talleres/pablo-merchante/)**
Junio 2022, Madrid

Fue un fin de semana de inmersión en la materia. De la mano del mentor, hemos hecho ejercicios para crear piezas con intención y aprenderemos cómo utilizar el fallo a nuestro favor. Hemos aprendido las nociones técnicas necesarias para poder dejar espacio a la intuición pero con criterio pictórico. Descubrimos cómo lograr que la plástica apoye el recorrido intelectual y poético. Apelamos a lo visceral, a la materia y a los recursos pictóricos para crear piezas de gran impacto y sinceras 0con nosotros mismos.

¡Si te quedaste con ganas de venir, escríbenos que pronto se vienen más experiencias como esta! **[info@fresco.art](mailto:info@fresco.art) **0

---

**Referencias de la voz propia**

![](https://fresco.art/wp-content/uploads/2022/08/Cristina-Banban_fresco.art_.jpeg)

Los bodegones de [Giorgio Morandi](https://art.us5.list-manage.com/track/click?u=e9d310075dc515b605aaa6985&id=b078f27aad&e=dce4afb302)

![](https://fresco.art/wp-content/uploads/2022/08/Laura-Lopez-Balza-fresco.art_.jpeg)

El universo expresionista de[ Laura López Balza](https://art.us5.list-manage.com/track/click?u=e9d310075dc515b605aaa6985&id=21f609eb95&e=dce4afb302), nuestra artista del curso [«Pintar para ver»](https://art.us5.list-manage.com/track/click?u=e9d310075dc515b605aaa6985&id=b2ca2ba402&e=dce4afb302) del 11 y 12 de junio en Madrid.

![](https://fresco.art/wp-content/uploads/2022/08/Hurvin-Anderson_fresco.art_.jpeg)

Los paisajes de [Hurvin Anderson](https://art.us5.list-manage.com/track/click?u=e9d310075dc515b605aaa6985&id=871e354c89&e=dce4afb302)

![](https://fresco.art/wp-content/uploads/2022/08/Oli-Epp-1024x1024.jpg)

Oli Epp

![](https://fresco.art/wp-content/uploads/2022/08/Ivana-de-Vivanco-906x1024.jpg)

Ivana de Vivanco

**Recursos**

**Aquí algunos enlaces de libros y otras fuentes que he consultado para inspirarme en este artículo:**
Libro “Diario de Pintura” de Miguel Gómez Losada
Libro “Inteligencias múltiples: La teoría en la práctica” de Howard Gardner
Libro “La intuición creadora en el arte y en la poesía» de Jacques Maritain
Artículo de CC/magazine “La teoría de las inteligencias múltiples de Gardner”

**Este contenido está curado y creado especialmente**
*Gracias por haber llegado hasta aquí. *
*Este contenido está creado para tratar ciertos temas del arte que nos inquietan y que habéis manifestado a través de nuestras redes, en respuesta al llamamiento de Enchastre que hemos hecho.*

***Si te quedaron dudas, quieres aportar un punto de vista distinto o sugerir un nuevo tema a abordar, puedes escribirme*** ***a enchastre@fresco.art ***
