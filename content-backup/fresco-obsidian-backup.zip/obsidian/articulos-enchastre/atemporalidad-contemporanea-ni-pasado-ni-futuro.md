---
title: "Atemporalidad contemporánea. Ni pasado ni futuro"
wordpress_id: 13954
content_type: post
status: "publish"
published_at: "2023-01-03T20:24:27"
modified_at: "2023-01-05T15:47:45"
slug: "atemporalidad-contemporanea-ni-pasado-ni-futuro"
source_url: "https://fresco.art/atemporalidad-contemporanea-ni-pasado-ni-futuro/"
categories: ["Enchastre"]
tags: ["Ampparito", "Betty Woodman", "Cristina BanBan", "Francesca Woodman", "Guggenheim", "Investigación pictórica", "Julio Galindo", "Los Bravú", "MET", "Maria Pratts", "MoMa", "Museo del Prado", "Museos", "New York", "Nueva York", "Pablo Merchante", "Reina Sofía", "TATE Modern", "abstracción", "arte conceptual", "arte contemporáneo", "arte urbano", "artista", "bellas artes", "cerámica", "colores", "danza", "escultura", "estudio", "fotografía", "intervención urbana", "lenguaje visual", "madrid", "naturaleza", "paleta", "pintura", "pintura abstracta", "pintura al óleo", "pintura figurativa", "proyecto", "residencia artística", "residencia de pintura", "taller", "talleres de pintura", "texturas"]
---
# Atemporalidad contemporánea. Ni pasado ni futuro

Entrega 5 – Enchastre:

![](https://fresco.art/wp-content/uploads/2022/06/Header-1024x400.jpg)

**Sobre la atemporalidad en el arte, ni pasado ni futuro. Un resumen de la entrega #5 **
**Si quieres recibir la editorial completa, suscríbete a nuestra Newsletter y te llegará a tu correo 🙂**

*En fresco. nos seduce ese velo de misterio que hay detrás de cada manifestación artística. Nos conmueve la generosidad y valentía de lxs artistas al compartir su mundo interior, para que las personas conozcan otras maneras de percibir la realidad. Vemos a la creación como un acto de amor profundo y por eso estamos aquí para ayudar a potenciarla.

Además notamos que hay una necesidad imperiosa de abordar algunos temas del mundo de la creación, particularmente de los procesos pictóricos. Por ello utilizaremos este medio para profundizar en diferentes temas.
*
Editorial e investigación by** [Brenda Ranieri](https://www.instagram.com/brendaranieri.studio/).**

![](https://fresco.art/wp-content/uploads/2023/01/5-1024x499.jpg)

![](https://fresco.art/wp-content/uploads/2023/01/Los-Bravu_fresco.art_-1024x772.jpg)

Detalle de obra de Los Bravú

*Detalle de la obra «Las sombras irreales os velan vuestra vista, haciendo que creáis que habrá una recompensa“ de [Los Bravú,](http://fresco.art/talleres/los-bravu/)* en Galería MPA, noviembre 2022.

>

**«Se me pide con frecuencia que explique cómo se ha desarrollado mi pintura. Para mí no existe en el arte ni el pasado ni el futuro. Si una obra de arte no puede mantenerse en el presente es que carece de significación. El arte de los griegos, de los egipcios, de los grandes pintores de otras épocas no representa un arte del pasado y tal vez esté hoy más vivo que nunca» **

**Pablo Picasso (1881-1973)**

Las formas armoniosas de las esculturas de mármol prehistóricas realizadas hace más de cuatro milenios en las islas Cícladas han inspirado a los escultores europeos modernos, desde Constantin Brancusi hasta Pablo Picasso y muchos artistas contemporáneos. **“Las artes de transición no existen. En la cronología de la historia del arte hay periodos más positivos, más completos unos que otros, hay mejores artistas en unas épocas y en otras… Pero no existe en el arte un progreso ascendente”. **Con esta declaración, Picasso reniega de la evolución en el mundo de la creatividad: un cuadro de Velázquez no es mejor ni peor que las pinturas de la tumba de Tutankamon; no ha mejorado cualitativamente la representación del ser humano, solo se representa de manera diferente, acorde con las necesidades o la cultura de una u otra época.

*Inspirada en mi reciente viaje a Nueva York, en lo que me fue capturando la atención este último tiempo y en los próximas experiencias fresco que se vienen este 2023, he seleccionado para este especial algunos temas como excusa para abordar un tema que me inquieta: ¿Qué queda perpetuo y qué desaparece a medida que avanzan los tiempos? O mejor dicho:*

### **¿Desaparece o se hace fósil?**

---

![](https://i2.wp.com/fresco.art/wp-content/uploads/2023/01/Los-Bravu_fresco.art45-819x1024.jpg?ssl=1)

![](https://i0.wp.com/fresco.art/wp-content/uploads/2023/01/Los-Bravu-1024x1024.png?ssl=1)

***¡En febrero tendremos el lujo de pintar con [Los Bravú](https://www.instagram.com/losbravu/) en su estudio!***

#### Taller intensivo
***[Escenas de un banquete.
Festín contemporáneo con Los Bravú](https://fresco.art/talleres/los-bravu/)***

**11 y 12 de febrero, Madrid**
Aforo Limitado.

***Dea y Diego son una pareja de jóvenes pintores que llevan varios años trabajando en la coyuntura del arte contemporáneo español y escalando a nivel internacional. **
En su obra vemos muy clara esta integración de imágenes de la cultura clásica y técnicas de pintura de los italianos, junto con elementos icónicos de la cultura pop y de su propio entorno.
*

![](https://fresco.art/wp-content/uploads/2023/01/Los-Bravu_fresco.art_taller-pintura-1024x768.jpg)

“Las sombras irreales os velan vuestra vista, haciendo que creáis que habrá una recompensa“ Los Bravú en Galería MPA, noviembre 2022.

>

**«Entendemos nuestro trabajo en Los Bravú como un estado Liminal, un monstruo bicéfalo cómodo entre disciplinas artísticas, entre la pintura académica y la expresión contemporánea, entre la cultura clásica y el pop» **

Los Bravú

### Investigación pictórica

![](https://i2.wp.com/fresco.art/wp-content/uploads/2023/01/Los-Bravu_fresco.art_pintura-1024x1024.jpg?ssl=1)

![](https://i1.wp.com/fresco.art/wp-content/uploads/2023/01/Los-Bravu_fresco.art_proceso-creativo_pintura-1024x1024.jpeg?ssl=1)

*Uno de los procesos que enriquece mucho el trabajo pictórico es el estudio previo, ya sea a nivel intelectual o narrativo, o a base de bocetos sueltos para estudiar la composición y formas de nuestro proyecto pictórico.*

[**En el taller de Los Bravú**](https://fresco.art/talleres/los-bravu/) tendremos el lujo de aprender cómo llevan ellos este proceso de investigación, dentro de su proceso creativo. Aprenderemos cómo enfocar el proceso pictórico profesional y luego incorporaremos en la pintura los recursos y diferentes técnicas que utilizan ellos mismos en sus obras que exponen en galerías, ferias y exposiciones tanto a nivel nacional como internacional.

![](https://i1.wp.com/fresco.art/wp-content/uploads/2023/01/Los-Bravu_fresco.art2_-819x1024.jpg?ssl=1)

![](https://i0.wp.com/fresco.art/wp-content/uploads/2023/01/Los-Bravu_talleres_fresco.art_-1024x1024.jpg?ssl=1)

#### [**Escenas de un banquete.
Festín contemporáneo con Los Bravú**](https://fresco.art/talleres/los-bravu/)

###### Taller intensivo en su estudio, Madrid
11 y 12 de febrero

Un fin de semana de festín entre la pintura académica y la expresión contemporánea, entre la cultura clásica y el pop, desde el taller de los  artistas.
La experiencia pictórica comenzará con un banquete que utilizaremos como excusa para hallar narrativas y componer obras llenas de expresión contemporánea.
**Basados en el proceso creativo de Los Bravú, haremos el ejercicio de tomar fotografías analógicas de la mesa. En una dinámica de duplas, aprenderemos cómo tomarlas y qué tener en cuenta para el uso pictórico. También haremos diversos estudios (bocetos) de lo que nos interpele. De esta manera, crearemos diversas escenas como si estuviéramos escribiendo frases sueltas de lo que será el guión de nuestra composición final. **
**En el segundo día del taller nos dedicaremos a construir la composición desde la pintura. Dea y Diego nos enseñarán sus diferentes técnicas pictóricas, para llevarlo luego a nuestro propio lenguaje. **

**¡Venid listos para disfrutar de un gran banquete! **
🍇 🏺 🥂 🖌️

¡Últimas plazas! Apúntate [**aquí.**](http://fresco.art/talleres/los-bravu/)

---

#### El arte etrusco:
Inspiración del arte contemporáneo

El Museo de la Cerámica de Barcelona ha descubierto la fuente de inspiración que halló Picasso en la cultura etrusca para ejecutar un vaso zoomorfo que realizó en Vallauris (Francia) en 1954. Hace unos años tuvo lugar una exposición en el Museo para demostrar los precedentes históricos de la cerámica española, el intercambio cultural entre las regiones del área mediterránea y el grado de sofisticación y de refinamiento de nuestros antepasados.

![](https://fresco.art/wp-content/uploads/2023/01/ceramica_Pablo-Picasso.jpeg)

![](https://fresco.art/wp-content/uploads/2023/01/ceramica-etrusca-478x340-1.jpeg)

*«Vaso zoomorfo» Pablo Picasso 1954* vs Terracota etrusca de la Antigüedad

El arte etrusco fue la forma de** arte figurativo producido por la civilización etrusca **que se desarrolló en **Italia entre el siglo IX y el siglo II a. C.** El arte que se conserva es de carácter funerario, relacionado tanto con la **pintura** (frescos) como con la **escultura**. Destaca en particular esta última, con sarcófagos de terracota a tamaño natural. También fueron **hábiles artesanos**, como los que pintaban sobre jarras de cerámica a imitación de los modelos griegos, y excelentes joyeros y metalúrgicos, destacando sus espejos de bronce grabados.

###### **Betty Woodman**
(New York, 1930 – 2018)
Arte etrusco, feminismo y percepción por encima de la realidad

Ceramista contemporánea que revolucionó el concepto de la cerámica funcional en EE.UU en los ochenta. Combinaba las formas arquitectónicas y cerámicas de la Roma clásica y del arte etrusco con la pintura y la interacción de la cerámica con el espacio y su representación.

En nuestro reciente viaje a NY, tuvimos la suerte de ver su exposición ***«Conversations on the Shore, works from the 1990s»* **en David Kordansky Gallery. Quedamos fascinados y por eso os contamos un poco de su obra:

>

**«Cuando pintas algo, cambia la percepción de lo que es en realidad»**

Betty Woodman

![](https://i0.wp.com/fresco.art/wp-content/uploads/2023/01/Betty-Woodman_fresco.art_enchastre_1-1021x1024.jpeg?ssl=1)

![](https://i2.wp.com/fresco.art/wp-content/uploads/2023/01/Betty-Woodman_fresco.art_enchastre_1-975x1024.jpg?ssl=1)

Betty Woodman jugaba con la representación de la vasija, haciendo que su cerámica «representara» una vasija, en lugar de serlo directamente.
Combinaba técnicas y materiales tradicionales con innovaciones propias, cruzando constantemente los límites entre las bellas artes y la artesanía para ampliar las posibilidades de la cerámica. La forma de sus jarrones queda casi borrada por la superficie pintada con una pincelada muy expresiva. Las alas grandes que sobresalen unidas a los lados tienen la forma de recipientes planos incompletos adornados con asas y otras protuberancias. Así, la pieza presenta una disposición de los objetos en el espacio, característica fundamental del género de la naturaleza muerta en las artes visuales.

![](https://fresco.art/wp-content/uploads/2023/01/Betty-Woodman_fresco.art_enchastre_3-2-1024x768.jpeg)

Parte de la exposición de Betty Woodman* «Conversations on the Shore, works from the 1990s»* que vimos este diciembre en David Kordansky Gallery, Nueva York.

---

#### **Apariencia y realidad**

*“Desde el punto de vista de las cosas más insignificantes de la vida, no somos un todo constituido materialmente, idéntico para todo el mundo (…) Nuestro error es creer que las cosas suelen presentarse tal y como son en realidad, los nombres tal y como se escriben, las personas según esa noción inmóvil que proporcionan de ella la fotografía y la psicología. De hecho no es eso en absoluto lo que vemos habitualmente. Vemos, oímos, concebimos el mundo de mala manera. Repetimos un nombre tal y como lo oímos hasta que la experiencia rectifique el error, cosa que no siempre sucede (…) No tenemos del universo sino visiones informes, fragmentadas, y que completamos con asociaciones de ideas arbitrarias, que crean sugestiones peligrosas”. * **Marcel Proust**

Hace un siglo **Marcel Proust (París, 1879-1922)** publicó esto ‘Por el camino de Swann’, primer tomo de su extraordinario ciclo ‘En busca del tiempo perdido’.  Este fragmento «Apariencia y realidad» es uno de los conceptos e ideas desarrolladas en dicho ensayo.

**Cualquier similitud con la realidad actual, es pura coincidencia 😉**

![](https://fresco.art/wp-content/uploads/2023/01/Scott-Katz-Ada-Ada-Resized.webp)

###### **Alex Katz**
(Nueva York, 1927)
Evocar una experiencia óptica tan visceral que apenas conserva una forma representacional.

>

**«Para mí, no existe una pintura realista que pueda hacerlo todo; si obtienes la luz, no puedes obtener todos los detalles, si obtienes los detalles, no entiendas la luz. El realismo es una variable».**

Alex Katz.

Emergiendo como artista a mediados del siglo XX, Katz forjó un modo de pintura figurativa que fusionaba la energía de los lienzos del expresionismo abstracto con las lenguas vernáculas estadounidenses de las revistas, las vallas publicitarias y las pantallas de cine. Ha recurrido a su entorno en el centro de la ciudad de Nueva York como tema principal, documentando una comunidad en evolución de poetas, artistas, críticos, bailarines y cineastas que han animado la vanguardia cultural desde la posguerra.  En la última década, Katz ha creado una serie de paisajes que revelan la economía visual en pinturas completamente inmersivas, evocando la unión de la luz y la naturaleza. Realizadas con gestos sueltos, las composiciones a veces se acercan a la abstracción total con solo un puñado de pinceladas seguras.

**«Ahora, en algunas de las cosas que pinto, dejo de lado la cosa y solo pinto la sensación», **comentó Katz recientemente.

Recientemente, tuvimos la suerte de verista Exposición en el Guggenheim, en Nueva York

![](https://fresco.art/wp-content/uploads/2023/01/AlexKatzGathering_enchastre_fresco.art_-1024x578.jpeg)

Detalle «Yellow Tree 1»,  Alex Katz, 2020. Óleo sobre lino. Obra que actualmente está exhibida en Gugghenheim NY

---

#### **[Introducción a lo profundo de la pintura.
Del error a lo fortuito con Pablo Merchante](https://fresco.art/talleres/pablo-merchante-23/)**

###### Taller intensivo, Madrid
21 y 22 de enero

Aforo completo

![](https://i0.wp.com/fresco.art/wp-content/uploads/2023/01/Pablo-1024x1024.png?ssl=1)

![](https://i0.wp.com/fresco.art/wp-content/uploads/2023/01/Pablo_Merchante_fresco.art1_-820x1024.jpg?ssl=1)

![](https://i1.wp.com/fresco.art/wp-content/uploads/2023/01/Pablo-Merchante_fresco.art_-819x1024.jpg?ssl=1)

Será un fin de semana de inmersión en la materia. Haremos ejercicios para crear piezas con intención y aprenderemos cómo utilizar el fallo a nuestro favor.
Aprenderemos las nociones técnicas necesarias para poder dejar espacio a la intuición pero con criterio pictórico. Descubriremos cómo lograr que la plástica apoye el recorrido intelectual y poético. Apelaremos a lo visceral, a la materia y a los recursos pictóricos para crear piezas de gran impacto y sinceras con nosotros mismos.
**Si te quedas con ganas de participar de esta experiencia, no te preocupes porque hay Parte 2, en junio! Más abajo te contamos todo 😉 **

#### **Ver la naturaleza con otros ojos**

Así como a **Betty Woodman** no le interesaba crear jarrones funcionales sino profundizar en la sensación que podían evocar esas vasijas de cerámica fragmentada como si estuvieran dispuestas en un bodegón; o como **Alex Katz **que en su obra más reciente está más inspirado en pintar el instante, captando la belleza y la abstracción de la luz natural; el escultor **Isamu Noguchi**, durante toda su carrera como escultor manifestó la sensibilidad inconformista hacia los lugares intermedios del mundo- aquellos fuera del alcance de la conciencia diaria de la mayoría de las personas- destacando un interés oir representar criaturas y fuerzas naturales como el cambio tectónico, la erosión y la gravedad.

>

**“Es mi deseo ver la naturaleza a través de los ojos de la naturaleza” **

Isamu Noguchi

Noguchi Isamu, (Los Ángeles, 1904-1988) fue un artista y arquitecto paisajista estadounidense cuya carrera artística abarcó seis décadas, desde la década de 1920 en adelante. Conocido por su escultura y obras de arte públicas, Noguchi también diseñó escenarios para varias producciones de *Martha Graham* y varias lámparas y muebles producidos en masa, algunos de los cuales todavía se fabrican y venden.

Museo al cual vale la pena visitar cuando viajes a Nueva York 😉

---

#### **[Naturaleza para la pintura.
Ritual, vigor e intuición con Pablo Merchante](https://fresco.art/talleres/residencia-artistica-pablo-merchante/)**

###### Residencia de pintura, Navalcarnero, Madrid
2 al 5 de junio

**¡Últimas matrículas! Más info [aquí](https://fresco.art/talleres/residencia-artistica-pablo-merchante/)**

##### ¡En junio tenemos cita en nuestra primera **Residencia Artística**! Can’t wait ❤️‍🔥

###### ¡Planazo! **Pintura, cine de verano, piscina, comida rica y actividades especiales como un taller con artista invitado y safari por cereales y viñedo aledaños**!

![](https://i2.wp.com/fresco.art/wp-content/uploads/2023/01/Pablo-residencia-1024x1024.png?ssl=1)

![](https://i0.wp.com/fresco.art/wp-content/uploads/2023/01/Residencia_Artistica_fresco.art2_.jpg?ssl=1)

![](https://i2.wp.com/fresco.art/wp-content/uploads/2023/01/Residencia_artistica_fresco.art_casa_5-1024x768.jpg?ssl=1)

![](https://i2.wp.com/fresco.art/wp-content/uploads/2023/01/Residencia_Artistica_fresco.art13-1024x768.jpg?ssl=1)

![](https://i1.wp.com/fresco.art/wp-content/uploads/2023/01/Residencia_Artistica_fresco.art40-1024x768.jpg?ssl=1)

![](https://i2.wp.com/fresco.art/wp-content/uploads/2023/01/Pablo_Merchante_residencia_fresco.art5_-819x1024.jpg?ssl=1)

![](https://i2.wp.com/fresco.art/wp-content/uploads/2023/01/Pablo_Merchante_residencia_fresco.art6_-819x1024.jpg?ssl=1)

![](https://i0.wp.com/fresco.art/wp-content/uploads/2023/01/Pablo-Merchante_fresco_2-1024x930.jpg?ssl=1)

![](https://i0.wp.com/fresco.art/wp-content/uploads/2023/01/Pablo-Merchante_fresco.art_experiencia-1024x768.jpg?ssl=1)

![](https://i0.wp.com/fresco.art/wp-content/uploads/2023/01/JULIO-GALINDO_fresco.art_.jpeg?ssl=1)

De la mano de [Pablo Merchante ](https://www.instagram.com/pablomerchanted/)tendrá lugar nuestra Residencia en una Casa Rural en Navalcarnero, Madrid.

**Esta propuesta polivalente pone a disposición espacios para la investigación pictórica, de la mano del consolidado pintor Pablo Merchante. ****Se trata de un conjunto de actividades y escenarios únicos donde el artista que participe podrá desarrollarse e impulsar su talento.  **Ya sea revisando su proceso creativo, aprendiendo sobre materiales, adquiriendo un modelo de trabajo más eficaz, obteniendo apoyo para desarrollar un proyecto o simplemente disfrutando de un ambiente inspirador, abierto al intercambio de opiniones y diálogo.

**Además, contaremos con actividades especiales como Taller con el ceramista contemporáneo [Julio Galindo](https://www.instagram.com/juliogalindostudio/) y Cine al aire libre, entre otras. **

>

**«Lo ritual, lo ancestral y el vigor de lo manual está siempre muy presente en mi forma de hacer. En mi forma de construir o destruir. Mi forma de vivir enfoca y vehiculiza mi forma de pintar» **

pablo merchante

##### La propuesta

Facilitar las condiciones y el espacio adecuado para la investigación pictórica es nuestro compromiso. Impulsar el intercambio y aportar iniciativas interesantes, nuestra motivación. Así surge esta propuesta donde de la mano de Pablo Merchante nos sumergiremos en lo profundo de la pintura, a través de diferentes actividades grupales e individuales.

Esta experiencia está dirigida a todas aquellas personas que quieran avanzar en su obra, desarrollar un trabajo de investigación pictórica o simplemente disfrutar de un ambiente inspirador, abierto al intercambio de opiniones y diálogo.
Grupo de 12 personas.

**¿Qué incluye?**

- 4 días de Residencia Artística con el pintor Pablo Merchante

- Investigación pictórica en la naturaleza

- Taller especial con el ceramista Julio Galindo (artista invitado)

- Cine al aire libre

- Safari de inspiración a cerealera y/o viñedo aledaños

- Trabajos individuales y grupales, de retroalimentación artística.

- Asesoramiento individual con el artista.

- Ambiente creativo para asegurar el disfrute al 100%: Casa Rural equipada, con piscina en un parque natural lleno de esculturas e inspiración.

- Incluye alojamiento, comidas y materiales especiales

[Aforo limitado **¡Últimas matrículas!**](https://fresco.art/talleres/residencia-artistica-pablo-merchante/) ¡ESTO VA A SER BRU-TALLLL!

---

###### **Andy Goldsworthy**
(Cheshire, 1956)
Arte conceptual para analizar la huella humana

Andy Goldsworthy es un escultor, fotógrafo y ecologista británico, residente en Escocia, que realiza arte conceptual en emplazamientos naturales y urbanos. Ha hecho de sus intervenciones en espacios naturales el sello identificador de su obra. Sus piezas que destilan sencillez, delicadeza y rotundidad, son una crítica profunda a la actividad mutiladora del ser humano sobre su entorno. **Aunque ha desarrollado proyectos para museos como la Tate Modern de Londres, el MoMA de San Francisco o el Reina Sofía de Madrid, una parte importante de la larga carrera de Andy Goldsworthy se ha ido construyendo en áreas naturales. **

![](https://i0.wp.com/fresco.art/wp-content/uploads/2023/01/GOLDSWORTHY-enchastre_fresco.art_palacio-de-cristal.jpeg?ssl=1)

![](https://i2.wp.com/fresco.art/wp-content/uploads/2023/01/ANDY-GOLDSWORTHY-enchastre_fresco.art_.jpg?ssl=1)

---

###### ***Marzo de Arte conceptual e intervención urbana con [Ampparito](https://www.instagram.com/ampparito/) *****🤯 🖤**

Un finde de trabajo de campo en el estudio y saldremos a la calle a realizar nuestro proyecto de intervención urbana.  **Experiencia muy exclusiva e imperdible!**

![](https://i1.wp.com/fresco.art/wp-content/uploads/2023/01/Ampparito_fresco.art_taller_intervencion-urbana-1024x1024.png?ssl=1)

![](https://i0.wp.com/fresco.art/wp-content/uploads/2023/01/Ampparito_fresco.art3_-1024x1024.jpg?ssl=1)

####
**[Hackear la norma.
Intervención urbana con Ampparito](http://fresco.art/talleres/ampparito/)**.

###### **11 y 12 de marzo, Madrid**
[¡Últimas plazas!](http://fresco.art/talleres/ampparito/)

***Un fin de semana donde la única premisa es romper las reglas del juego.**
Comenzaremos con ejercicios de alterar objetos, significados y espacios para provocar nuevos comportamientos. **Construiremos así diferentes experiencias, adaptándonos a lo que no estábamos acostumbrados. Luego de haber entrenado esta manera de pensar, trabajaremos en un proyecto grupal de intervención urbana para realizar al siguiente día.** El domingo saldremos a la calle a desarrollar nuestra obra de intervención urbana. Irrumpiremos, adaptándonos a la ciudad, pero con un toque poético y efímero. Lejos de vandalizar el barrio, pintar o quitar cosas, añadiremos algo a lo que existe.
**Una oportunidad única de trabajar de la mano de un artista contemporáneo como Ampparito y descubrir desde dentro el contexto de su brillante trabajo.

¡Venid con los ojos bien abiertos!***

🔍 👀 🫀

![](https://i1.wp.com/fresco.art/wp-content/uploads/2023/01/Ampparito_fresco.art1_-1024x1024.jpg?ssl=1)

![](https://i1.wp.com/fresco.art/wp-content/uploads/2023/01/Ampparito_fresco.art18-1024x1024.jpg?ssl=1)

>

**«Me gusta destruir la utilidad para poder construir desde otras premisas más poéticas o simbólicas. Esta metodología que aún estoy construyendo implica abordar temas complejos desde un punto de vista pretendidamente naif, con el objetivo de crear dobles sentidos, alegorías o absurdos que rompan aquello que damos por sentado.»**

Ampparito

![](https://fresco.art/wp-content/uploads/2023/01/Ampparito-1024x683.jpeg)

Ampparito

---

###### **¿Pero… esto es arte? ¿Desobedecer o querer ser gobernado?
Álvaro Perdices – CA2M**

>

**«Trabajar en el medio artístico es una actividad que abarca distintos ámbitos, desde lo profesional a lo personal. Desde involucrarse y estar,  a ir contra-corriente y acabar siendo un inadaptado» **

ÁLVARO PERDICES

**Álvaro Perdices** (Madrid,1971) desarrolló su carrera y formación durante veinte años en Los Ángeles. Ha sido coordinador de exposiciones en el **Museo del Prado de Madrid** habiendo desarrollado en paralelo proyectos educativos, de comisariado y exposiciones.
En su práctica artística y vital investiga las razones y las estrategias con las que opera en este medio. Respondiendo, según afirma, a la simple idea de no estar de acuerdo con aquello que nos viene dado. Evidenciar la desobediencia por medio de las formas del lenguaje o las respuestas informes pueden quebrar los cánones, alumbrando la posibilidad de lo individual. Su trabajo artístico ha estado vinculado con instituciones del ámbito educativo o museístico. Durante la primera parte del 2022 ha desarrollado su exposición **Espejo y reino/ Ornamento y estado en el CA2M**:

---

#### **Más de un diciembre en Nueva York**

También tuve la suerte de ver dos exposiciones de dos artistas españolas que me gustan mucho:

###### **[Cristina Ban Ban](https://www.instagram.com/cristina_banban/)**
[Skarstedt Gallery, New York](https://www.galleriesnow.net/gallery/skarstedt-gallery/)
«Mujeres»

![](https://i0.wp.com/fresco.art/wp-content/uploads/2023/01/IMG_2168-1024x768.jpeg?ssl=1)

![](https://i2.wp.com/fresco.art/wp-content/uploads/2023/01/IMG_2196-1024x768.jpeg?ssl=1)

![](https://i2.wp.com/fresco.art/wp-content/uploads/2023/01/IMG_2175-1024x768.jpeg?ssl=1)

![](https://i1.wp.com/fresco.art/wp-content/uploads/2023/01/IMG_2181-1024x768.jpeg?ssl=1)

![](https://i0.wp.com/fresco.art/wp-content/uploads/2023/01/IMG_2173-1024x768.jpeg?ssl=1)

Las diversas mujeres en el universo de BanBan no se encuentran con la mirada del espectador, ni necesariamente se relacionan con quienes las rodean. Si bien esto puede hablar del sentimiento generalizado de aislamiento en nuestra sociedad contemporánea, también subraya la autoridad y la confianza de estos personajes. Su obra en directo trasmite una desnudez natural, no sexualizada y con personalizad propia. Asimismo, las grandes manos y los ojos tan característicos de la obra de BanBan evidencian una presencia majestuosa pero íntima y sensible.

###### **[Marria Pratts](https://www.instagram.com/marriapratts/)**
La Bibi / The Boiler 191, New York
«MELTED WITH U»

![](https://i1.wp.com/fresco.art/wp-content/uploads/2023/01/IMG_2086-1024x768.jpeg?ssl=1)

![](https://i1.wp.com/fresco.art/wp-content/uploads/2023/01/IMG_2089-1024x768.jpeg?ssl=1)

![](https://i0.wp.com/fresco.art/wp-content/uploads/2023/01/IMG_2090-1024x768.jpeg?ssl=1)

![](https://i1.wp.com/fresco.art/wp-content/uploads/2023/01/IMG_2092-1024x768.jpeg?ssl=1)

![](https://i0.wp.com/fresco.art/wp-content/uploads/2023/01/IMG_2095-1024x768.jpeg?ssl=1)

![](https://i1.wp.com/fresco.art/wp-content/uploads/2023/01/IMG_2096-1024x768.jpeg?ssl=1)

![](https://i1.wp.com/fresco.art/wp-content/uploads/2023/01/IMG_2102-1024x768.jpeg?ssl=1)

«The alterity of children means they appreciate how a landscape can exist in absence of representation or the colour green; how fire can be an expressive field of action engaging twin modes of destruction and desire; how a kernel of marks knotted like a starburst is not simply a tenet of ‘action painting’, but part of a lexicon of cat-and-mouse skirmishes and hair-raising frission». Elaine Tam. November, 2022

---

**Referencias porque sí**

***Antes de cerrar este artículo, os dejo un popurrí de algunos artistas contemporáneos que me han estado inspirando en el último tiempo***:

![](https://fresco.art/wp-content/uploads/2023/01/Mitso-Muira_enchastre.CA2M.jpeg)

[Mitso Muira](https://www.google.com/search?q=mitsuo+miura&oq=mitsuo+miura&aqs=chrome.0.0i13i355i512j46i13i512j0i22i30l4j69i60l2.335j0j7&sourceid=chrome&ie=UTF-8)

![](https://fresco.art/wp-content/uploads/2023/01/francesca-woodman-enchastre_fresco.art_.jpg)

[Francesca Woodman](https://www.google.com/search?q=Francesca+Woodman&oq=Francesca+Woodman&aqs=chrome..69i57j0i512l3j46i512j69i60l3.189j0j7&sourceid=chrome&ie=UTF-8)

![](https://fresco.art/wp-content/uploads/2023/01/Ornella-Pocetti_fresco.art_enchastre.jpg)

[Ornella Pocetti](https://www.instagram.com/ornellapocetti/)

![](https://fresco.art/wp-content/uploads/2023/01/Barbara-Hepworth_enchastre_fresco.art_.jpeg)

[Barbara Hepworth](https://www.google.com/search?q=barbara+hepworth&source=lmns&bih=646&biw=1440&hl=en&sa=X&ved=2ahUKEwjP__X_86P8AhUTuEwKHSrnAboQ_AUoAHoECAEQAA)

**BONUS DE EXPOS, PODCAST, PELIS Y DOCUMENTALES**

***Un popurrí de todo:***
[Los Bravú. La hora del Gallo ](https://www.instagram.com/p/CmKHYYljeY_/)
[Podcast de Victoria Rivers: entrevista a Los Bravú](https://www.ivoox.com/en/conversaciones-51-los-bravu-audios-mp3_rf_97104718_1.html)
[Mitsuo Miura. Casi 400 m² para dos paisajes](https://ca2m.org/exposiciones/mitsuo-miura-casi-400-m2-para-dos-paisajes)
[Zóbel. El futuro del pasado](https://www.museodelprado.es/actualidad/exposicion/zobel-el-futuro-del-pasado/27cf157b-5bd7-41d7-b093-137955121f20)
[El Bosco: el jardín de los sueños](https://www.filmin.es/pelicula/el-bosco-el-jardin-de-los-suenos?origin=searcher&origin-type=primary)
[El misterio de Picasso](https://vimeo.com/335671350)
[The Woodman’s](https://youtu.be/5zqNUdtCwkU)

**RECURSOS**

**Aquí algunos enlaces de libros y otras fuentes que he consultado para inspirarme en este artículo:**
Tate Museam (TateShots y TateTalks)
Isamu Noguchi Museam New York
MoMa New York
MET New York
Biblioteca Reina Sofía

**Este contenido está curado y creado especialmente
¡*Gracias por haber llegado hasta aquí*!**

*Este contenido está creado para tratar ciertos temas del arte que nos inquietan y que habéis manifestado a través de nuestras redes, en respuesta al llamamiento de Enchastre que hemos hecho.*

***Si te quedaron dudas, quieres aportar un punto de vista distinto o sugerir un nuevo tema a abordar, puedes escribirme*** ***a enchastre@fresco.art ***

[Síguenos en Instagram!](https://www.instagram.com/fresco.arte/)
