---
title: "¿Cómo mezclamos los materiales?"
wordpress_id: 12228
content_type: post
status: "publish"
published_at: "2022-06-08T22:26:08"
modified_at: "2022-08-01T10:18:49"
slug: "como-mezclamos-los-materiales"
source_url: "https://fresco.art/como-mezclamos-los-materiales/"
categories: ["Enchastre"]
tags: ["Javier Ruiz", "aprender a pintar", "arte", "arte contemporáneo", "artista", "colores", "etudio de color", "madrid", "materiales", "paleta", "pigmentos", "pintura acrílica", "pintura al óleo", "talleres de pintura"]
---
# ¿Cómo mezclamos los materiales?

Entrega 1 – Enchastre:

![](https://fresco.art/wp-content/uploads/2022/06/Header-1024x400.jpg)

Sobre experimentación de materiales, estudios de color y descubrimientos del oficio del pintor

*En fresco. nos seduce ese velo de misterio que hay detrás de cada manifestación artística. Nos conmueve la generosidad y valentía de lxs artistas al compartir su mundo interior, para que las personas conozcan otras maneras de percibir la realidad. Vemos a la creación como un acto de amor profundo y por eso estamos aquí para ayudar a potenciarla.

Además notamos que hay una necesidad imperiosa de abordar algunos temas del mundo de la creación, particularmente de los procesos pictóricos. Por ello utilizaremos este medio para profundizar en diferentes temas.
*

![](https://fresco.art/wp-content/uploads/2022/06/1-1024x499.jpg)

#### **La importancia de seguir los principios «correctos**«

***Una de las razones de la prolongada popularidad de la pintura al óleo es la flexibilidad de las reglas que gobiernan su correcta aplicación, y el margen que existe entre el ideal de perfección y la práctica normal. ***

*A pesar de las muchas reglas con las que uno debe familiarizarse, el pintor no debe considerarlas como obstáculos que interfieran con su libre expresión.*

Si la pintura al óleo exigiera un cumplimiento estricto de estas reglas, prestando meticulosa atención a la exactitud de cada operación, es dudoso que su popularidad se hubiera mantenido tanto tiempo. Existe un amplio margen de libertad en la aplicación de las pinturas al óleo; la regla general consiste en seguir los principios y procedimientos con sentido común, sin apartarse demasiado de la línea correcta.

Por ejemplo, se aconseja no sobrecargar el lienzo con capas sólidas de pintura espesa; pero al mismo tiempo, el ***empaste*** está entre los atributos más atractivos de muchos estilos de pintura.  Sólo hay que ser consciente de que existe un punto más allá del cual resulta peligroso apartarse del ideal técnico.

Otro ejemplo es la advertencia en contra de las mezclas de un material sobre el otro. Para los académicos sólo en ciertos casos extremos corre peligro la longevidad del cuadro, como cuando se infringe generalmente la regla básica de pintar ***graso sobre magro.***

**Regla Básica «Graso sobre Magro»:**
(Un pequeño inciso por si la primera vez que escuchas hablar de esto)

Todos los métodos de pintura al óleo conllevan la realización de capas. Para que estas capas funcionen y la pintura no se cuartee debemos realizarlas con un orden: las primeras capas más livianas, donde podemos mezclar el óleo con disolvente y lograr así una capa con menos aceite; y las siguientes capas con mayor densidad de aceite, donde podemos utilizar también Médium (liquin) para ayudar a la flexibilidad del óleo.

1º Capa: Óleo + Disolvente
2º Capa: Óleo + Un poco de médium
3º Capa: Óleo + Médium en mayor cantidad

El motivo principal por el que tienes que tener en cuenta esta técnica es evitar que la pintura se cuartee con el tiempo.

#### **La importancia de seguir la intuición**

***Ok. Es necesario conocer las reglas básicas sí, pero atenti que esto no nos limite a la hora de probar nuevas técnicas o explorar nuevos efectos pictóricos.
Hay que dejarle espacio a la intuición y el sentido común que son los que nos guiarán por el camino correcto en el diálogo con nuestra obra.***

En este camino hacia el propio lenguaje, muchos artistas experimentan con materiales y hacen pruebas dentro de su taller. Esta alquimia les permite hallar un sistema propio que se traduce en la personalidad de la obra. Por ejemplo, [Jazzy Dope](https://art.us5.list-manage.com/track/click?u=e9d310075dc515b605aaa6985&id=f18dcb8181&e=dce4afb302) utiliza algunos detalles en srpay en muchas de sus obras, que le da un toque más *urbano* y le recuerdan a su época de *grafitero*, según lo cuenta en nuestro curso online.
En este caso, mezcla spray con óleo pero en algunas zonas puntuales de su obra, con un sentido y un criterio creativo:***«Es genial luego cuando arañamos el óleo aún mordiente con las espátulas, que esté por debajo el spray (…)  Porque al final luego también tienes otro tipo de superficie, otra textura con la que puedes trabajar, jugar con las espátulas, y le va a dar un acabado mucho más urbano, por decirlo de alguna forma»***

![](https://fresco.art/wp-content/uploads/2022/06/2-819x1024.jpeg)

Ilustración de [David Shrigley,](https://art.us5.list-manage.com/track/click?u=e9d310075dc515b605aaa6985&id=d00b1547c6&e=dce4afb302) que si no lo sigues todavía, te recomiendo mucho 🙂

**Añadir pigmentos al óleo**

***Otro gran protagonista a la hora de hablar de mezclas para óleo y que muchos artistas contemporáneos utilizan. Es una gran herramienta si buscas saturar más tu paleta de colores y lograr así tonalidades y texturas más expresi******vas***.

Un pigmento es una sustancia coloreada y finamente repartida que confiere su color a otro material, al mezclarse con él. Es un colorante que le agrega diferentes matices de color al material que estés usando (óleo, acuarelas, etc). El pigmento es siempre el mismo para todas las clases de pintura, lo que cambia es el método de la mezcla.

Los pigmentos como la tierra verde, el verde ultramar, el rojo o el violeta que tienen poco poder cubriente, se usan más para veladuras que para manchas opacas. Los azules cobalto y los verdes turquesas de imitación,  son igual de permanentes y tienen las mismas propiedades físicas que el azul ultramar. El rojo indio tiene una tonalidad rosada o azulada, y el rojo de cadmio claro tiene una tonalidad amarillenta o asalmonada. En las pinturas al óleo, estos dos productos se usan con preferencia sobre las tierras rojas naturales y el rojo veneciano (artificial), que tienen menos calidad.

Si te interesa este tema de Pigmentos, puedes leer más en el tradicional libro *«Materiales y técnicas del arte» de Ralph Mayer* donde hay mucha información sobre los tonos y su uso. (Se recomienda un cuidadoso manejo para estas sustancias.)

En nuestro taller [«El oficio del pintor: estudio para un Paisaje Surrealista Figurativo»](https://art.us5.list-manage.com/track/click?u=e9d310075dc515b605aaa6985&id=13637f81c6&e=dce4afb302) con Javier Ruiz de febrero 2022, hemos montado un laboratorio de materiales donde hicimos estudios de color, vimos qué marcas comprar y cómo mezclar el óleo con pigmentos, uno de los grandes recursos del artista para lograr su característica pincelada.

![](https://fresco.art/wp-content/uploads/2022/06/Taller_fresco_javier_ruiz_estudio_color_oleo-1024x945.png)

![](https://fresco.art/wp-content/uploads/2022/06/Taller_fresco_javier_ruiz_oleo-2-925x1024.png)

**Este contenido está curado y creado especialmente**

***Gracias por haber llegado hasta aquí leyendo. Este contenido está creado para tratar ciertos temas del arte que nos inquietan y que habéis manifestado a través de nuestras redes, en respuesta al llamamiento de Enchastre que hemos hecho.***

**Puedes seguirnos y ver el resto de contenido que creamos para haceros la vida creativa un poco más fácil 🙂**

[Síguenos en Instagram](https://art.us5.list-manage.com/track/click?u=e9d310075dc515b605aaa6985&id=2c9cbbbffb&e=dce4afb302)
