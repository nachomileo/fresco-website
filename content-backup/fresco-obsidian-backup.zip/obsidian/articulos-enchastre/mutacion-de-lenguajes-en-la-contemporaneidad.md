---
title: "Mutación de lenguajes en la contemporaneidad"
wordpress_id: 14908
content_type: post
status: "publish"
published_at: "2023-08-05T15:27:22"
modified_at: "2023-08-05T17:13:09"
slug: "mutacion-de-lenguajes-en-la-contemporaneidad"
source_url: "https://fresco.art/mutacion-de-lenguajes-en-la-contemporaneidad/"
categories: ["Enchastre"]
tags: ["Barcelona", "Guido Sarli", "Investigación pictórica", "Javier Ruiz", "Juan Narowé", "Justine Menard", "Museos", "abstracción", "arte contemporáneo", "artista", "bellas artes", "cerámica", "colores", "danza", "dibujo contemporáneo", "escultura", "estudio", "fotografía", "lenguaje visual", "madrid", "movimiento", "narrativa", "naturaleza", "personajes", "pintura", "pintura abstracta", "pintura al óleo", "pintura figurativa", "proyecto", "retiro artistico", "soplado de vidrio", "taller", "talleres de pintura", "texturas"]
---
# Mutación de lenguajes en la contemporaneidad

Entrega #6 – Enchastre:

![](https://fresco.art/wp-content/uploads/2023/08/6-1024x576.jpg)

**MUTACIÓN DE LENGUAJES EN LA CONTEMPORANEIDAD. **

*En fresco. diseñamos experiencias que nos ayuden a investigar la evolución de los diferentes lenguajes artísticos. Nuestra intención es proponer **herramientas de profesionalización** para impulsar la creación contemporánea, observando lo que nos rodea y despertar a la posibilidad de **convertir lo cotidiano en extraordinario**.

Enchastre es nuestro blog, un espacio de **reflexión e investigación** que complementa esta convicción. En esta **#6 entrega** te contamos sobre lo último que hemos estado leyendo, recomendaciones de música, expos, pelis, podcast de arte y te adelantamos detalles de nuestras [próximas experiencias](https://fresco.art/#booknow).

**¡Que disfrutes de la lectura de veano, nos vemos muy pronto!***

**Si quieres recibir la editorial completa, [suscríbete a nuestra Newsletter](http://fresco.art/#newsletter) y te llegará a tu correo**.

Editorial e investigación by** [Brenda Ranieri](https://www.instagram.com/brendaranieri.studio/).**

![](https://fresco.art/wp-content/uploads/2023/08/enchastre-_6-copy-1024x288.jpg)

Todo lenguaje visual conduce a una reflexión en torno a **una sociedad que** cambia, evoluciona (o involuciona), se interconecta, se fragmenta, se vuelve a unir, se manifiesta, **late**. El arte expone una respuesta a ese movimiento, a ese fluir entre la expansión y la contracción, y propone muchas veces el cambio. Muchxs artistas escenifican una respuesta a las mutaciones contemporáneas, algunxs expresan su universo imaginario utilizando la contemporaneidad como plató y otros irrumpen con su vanguardia. Este artículo es una observación de cómo los lenguajes artísticos se mueven constantemente, para hallar un **ritmo propio** dentro del maremágnum en el que vivimos y analizar cómo y cuándo subirse a la ola.

##### ****CUTEISM MOVEMENT
*****y otras prácticas de la pintura figurativa*

Hay muchas maneras de ver la **belleza** en el mundo del arte, pero se entiende que el contemporáneo no busca lo bello en sí. Busca la creatividad, la emancipación artística e interacción con el público. Busca que el artista pueda demostrar su universo creativo e **inspirar exponiendo su percepción** sobre lo que le rodea. Sin embargo, aunque el arte contemporáneo no tenga como objetivo «lo bonito», una obra de arte contemporánea sí puede ser bella. Tanto como público y como artistas es importante formar nuestro **propio juicio y crítica** de lo que vemos, decidir con qué nos quedamos y qué descartamos para seguir evolucionando. Hay una parte de objetividad y otra de subjetividad, donde lo que prima siempre es la **autenticidad***.*

>

**“Me encanta trabajar con artistas que expresan libremente sus sentimientos, pasiones y fobias sin esperar nada a cambio que no sea que se escuche su voz.» **

**Pablo Villazan, de Villazan Gallery N.Y.**

---

**¡En octubre pintamos con Javier Ruiz en su Nave industrial!**

#### **[La pintura tras bambalinas.](https://fresco.art/talleres/javier-ruiz-23/)
*Retiro de creación interdisciplinar con [Javier Ruiz](https://www.instagram.com/javierruiz_studio/)***
**13 al 15 de Octubre, Jaén**
3 días | en la Nave industrial del artista

Una experiencia de **creación interdisciplinar para artistas con inquietudes**. Esta propuesta pone al alcance los recursos para un proceso pictórico de libre creación para **enriquecer el proceso creativo, desarrollar un proyecto, incorporar herramientas nuevas y dialogar sobre lo que nos inquieta.** Habrá instancias de mentoría individual con el artista donde podamos **exponer a la crítica** nuestro trabajo o **tener orientación**sobre algún tema puntual (desde uso de materiales, cómo gestionar nuestro trabajo, comunicar nuestra obra, etc.). Un espacio que da lugar a la **experimentación, la investigación, el diálogo y la inspiración en un campo de trabajo profesional**

[Ver más](https://fresco.art/talleres/javier-ruiz-23/)

**Aforo limitado. Consúltanos por tu plaza a [info@fresco.art](mailto:info@fresco.art)**.

[

![](https://fresco.art/wp-content/uploads/2023/08/Javier-Ruiz_fresco.art_retiro14-edited.jpg)

](https://fresco.art/talleres/javier-ruiz-23/)

>

**«Me alimento de la contemporaneidad para generar una reflexión vital. Mi obra es muy escenográfica: busco el impacto que se genera ‘al abrirse el telón’, una pequeña ventana al mundo que vivimos, que trata de reflexionar sobre todo aquello que nos preocupa, vida, muerte, anhelos…» **

**Javier Ruiz.**

[

![](https://fresco.art/wp-content/uploads/2023/07/Javier-Ruiz-1-576x1024.jpg)

](https://fresco.art/talleres/javier-ruiz-23/)

[

![](https://fresco.art/wp-content/uploads/2023/07/Javier-Ruiz_fresco.art_retiro23-819x1024.jpg)

](https://fresco.art/talleres/javier-ruiz-23/)

[

![](https://fresco.art/wp-content/uploads/2023/07/Javier-Ruiz_fresco.art_retiro25-820x1024.jpg)

](https://fresco.art/talleres/javier-ruiz-23/)

[

![](https://fresco.art/wp-content/uploads/2023/07/Javier-Ruiz_fresco.art_retiro11-819x1024.jpg)

](https://fresco.art/talleres/javier-ruiz-23/)

[

![](https://fresco.art/wp-content/uploads/2023/07/Javier-Ruiz_fresco.art_retiro26-1024x768.jpg)

](https://fresco.art/talleres/javier-ruiz-23/)

[

![](https://fresco.art/wp-content/uploads/2023/07/Javier-Ruiz_fresco.art_retiro6-819x1024.jpg)

](https://fresco.art/talleres/javier-ruiz-23/)

---

##### **«LO QUE PERSIGO POR SOBRE TODO ES LA EXPRESIÓN»**

Explorar diferentes formas de expresión podría ser una buena definición de cómo los artistas actuales responden a un mundo tan cambiante, donde cada vez surgen más artistas multidisciplinares. Ya en el S.XX **Henri Matisse** exponía esta tendencia en varios ensayos recopilados en el libro **«Apuntes de un pintor»,** donde devela algunas de sus ideas sobre el mundo de la creación y particularmente sobre el arte de pintar (o dibujar, que para él son la misma cosa). Aquí una extracción de algunos fragmentos: **“El fondo de mi pensamiento no ha cambiado, pero mi pensamiento ha evolucionado y mis medios de expresión se han ido adaptando a esa evolución”** (p. 51). Asimismo: **“El pensamiento de un pintor no debe ser considerado fuera de sus medios” **(p. 52). Y sobre todo: **“Lo que persigo por sobre todo es la expresión” (p. 52). Los medios del pintor son, pues, modos de expresión».**

Matisse explicando su relación con el dibujo y la pintura desde un prisma de unidad o simbiosis. En definitiva para él son la misma cosa. [**Aquí**](https://www.instagram.com/p/CtO4et3M0We/) puedes ver la traducción del vídeo en español.

---

##### ****LA SIMPLEZA QUE APARENTA SER BREVE Y ES INFINITA ****
*esta es la sensación que evoca el lenguaje pictórico de [Juan Narowé](https://www.instagram.com/nnarowe/)*

En [noviembre](https://fresco.art/talleres/juan-narowe/) descubriremos la ingenuidad y elegante sencillez de la línea, de la mano de Juan Narowé. **Simpleza y lo cotidiano** se unen en un mismo lenguaje: Dibujos superpuestos como una idea sobre otra, líneas argumentales que se cruzan, **conversaciones con uno mismo como si hubiéramos dibujado todo el mantel con nuestros pensamientos**.

#### **[*Narrativas del dibujo contemporáneo*](https://fresco.art/talleres/juan-narowe/) con [Juan Narowé](https://fresco.art/talleres/juan-narowe/)**
**25 al 26 de Noviembre, Madrid**
2 días | Taller en Carabanchel

[Ver más](https://fresco.art/talleres/juan-narowe/)

**Aforo limitado. Consúltanos por tu plaza a [info@fresco.art](mailto:info@fresco.art)**.

El lenguaje contemporáneo ve al dibujo como parte del entendimiento pictórico, no sólo como recurso para estudiar o bocetar una idea o composición, sino también como expresión final. Inspiradas en el proceso creativo de **Juan Narowé**, trabajaremos con diferentes medios creando palimpsestos materiales: **una especie de mapas mentales de dibujos**, donde podremos expresar pensamientos, crear personajes, probar diferentes gestos, superponer formas y soltar líneas que nos ayuden a ablandar la mano (y la mente).
La propuesta es conocer los diferentes **recursos, materiales y soportes** aplicados a la práctica del dibujo en la contemporaneidad. El primer día experimentaremos con diversos materiales **sobre papel o libreta**. Al día siguiente veremos cómo plasmar este universo de líneas a través de pintura **sobre tela**. Durante todo el taller Juan nos aportará ejercicios para **crear narrativas y personajes** como herramientas para expresar sentimientos, historias o ideas.

[

![](https://fresco.art/wp-content/uploads/2023/07/Juan-Narowe-2-576x1024.jpg)

](https://fresco.art/talleres/juan-narowe/)

[

![](https://fresco.art/wp-content/uploads/2023/07/Juan-Narowe_fresco.art42-819x1024.jpg)

](https://fresco.art/talleres/juan-narowe/)

[

![](https://fresco.art/wp-content/uploads/2023/07/Juan-Narowe_fresco.art9_-846x1024.jpg)

](https://fresco.art/talleres/juan-narowe/)

[

![](https://fresco.art/wp-content/uploads/2023/07/Juan-Narowe_fresco.art56-849x1024.jpg)

](https://fresco.art/talleres/juan-narowe/)

[

![](https://fresco.art/wp-content/uploads/2023/07/Juan-Narowe_fresco.art41-819x1024.jpg)

](https://fresco.art/talleres/juan-narowe/)

[

![](https://fresco.art/wp-content/uploads/2023/07/Juan-Narowe_fresco.art47-819x1024.jpg)

](https://fresco.art/talleres/juan-narowe/)

[

![](https://fresco.art/wp-content/uploads/2023/07/Juan-Narowe_fresco.art48-819x1024.jpg)

](https://fresco.art/talleres/juan-narowe/)

[

![](https://fresco.art/wp-content/uploads/2023/07/Juan-Narowe_fresco.art49-819x1024.jpg)

](https://fresco.art/talleres/juan-narowe/)

>

**«La obra de Juan Narowé se mueve entre el dibujo y la pintura con frecuentes incursiones en la autoedición y la obra gráfica. Sus narraciones se nutren de sofisticadas referencias a diferentes disciplinas como la literatura y el cine. A menudo, la punta del juego de Narowé son fragmentos, recuerdos de una sobremesa, una conversación o un encuentro: restos anodinos de un momento compartido. Historias y objetos aparentemente muy sencillos pero cuyo poder de evocación es infinitamente cautivador.» **

**Francesco Giaveri.**

---

##### ****INTRODUCIR LO COTIDIANO EN EL ARTE**
***Performance, el cuerpo y el paso del tiempo como forma de expresión. *

*Posiblemente este objetivo es uno de los más iterados desde la década de los 80, época en la cual se puso de manifiesto un fenómeno social en Madrid en los campos social, cultural, artístico, económico, etc. Una explosión de creatividad que va más allá de su famosa “Movida”. Un ejemplo de una artista protagonista de esta época es **Esther Ferrer**, junto con **Antonio López, Eduardo Arroyo, Miguel A. Campano, Paloma Navares**, entre otros. A continuación va una entrevista muy inspiradora que le hace la curadora del **Museo Gugghenheim Bilbao** a **Esther Ferrer**, esta artista pionera que a través de su trayectoria nos relata cómo la **performance**, el **cuerpo** y el **paso del tiempo** tienen una gran importancia **como forma de expresión**:*

Conversación con Esther Ferrer | Museo Guggenheim Bilbao .

---

#### **[Bailar lo liminal.](https://fresco.art/talleres/guido-sarli/)
Laboratorio de movimiento con [Guido Sarli](https://www.instagram.com/guido_sarli/)**
[7 de Octubre, BARCELONA.](https://fresco.art/talleres/guido-sarli/)
1 día | 4 hs.

[Ver más](https://fresco.art/talleres/guido-sarli/)

**Aforo limitado. Consúltanos por tu plaza a [info@fresco.art](mailto:info@fresco.art)**

Un cuerpo en movimiento dibuja líneas, ritmos y transmuta emociones. La imagen y el cuerpo son herramientas de expresión muy poderosas y en esta experiencia tendremos el placer de experimentarlas en todo su esplendor. **[Bailar lo liminal](https://fresco.art/talleres/guido-sarli/)** es una invitación a disfrutar del estado de transición que posibilita el movimiento, llevando al cuerpo a los límites de velocidad, potencia, transformación,  coordinación y conciencia. Como parte del **entendimiento del movimiento**, registraremos con lápices de colores líneas o sensaciones que nos sirvan como eslabones para expresar emociones o **completar un impulso catártico. **

Workshop by Guido Sarli

>

**«El cuerpo y sus posibilidades dinámicas son el portal que nos conduce a dibujar nuestra propia narrativa y ampliar nuestro imaginario en movimiento.» **

Guido Sarli

![](https://i1.wp.com/fresco.art/wp-content/uploads/2023/07/Guido-Sarli-1-576x1024.jpg?ssl=1)

![](https://i0.wp.com/fresco.art/wp-content/uploads/2023/07/Guido-Sarli_fresco.art1_-820x1024.jpg?ssl=1)

![](https://i0.wp.com/fresco.art/wp-content/uploads/2023/07/Guido-Sarli_fresco.art10.jpg?ssl=1)

![](https://i2.wp.com/fresco.art/wp-content/uploads/2023/07/Guido-Sarli_fresco.art12-819x1024.jpg?ssl=1)

![](https://i2.wp.com/fresco.art/wp-content/uploads/2023/07/Guido-Sarli_fresco.art2_-819x1024.jpg?ssl=1)

![](https://i1.wp.com/fresco.art/wp-content/uploads/2023/07/Guido-Sarli_fresco.art5_-819x1024.jpg?ssl=1)

![](https://i2.wp.com/fresco.art/wp-content/uploads/2023/07/Guido-Sarli_fresco.art7_.jpg?ssl=1)

![](https://i0.wp.com/fresco.art/wp-content/uploads/2023/07/Guido-Sarli_fresco.art13-819x1024.jpg?ssl=1)

![](https://i2.wp.com/fresco.art/wp-content/uploads/2023/07/Guido-Sarli_fresco.art14-820x1024.jpg?ssl=1)

![](https://i2.wp.com/fresco.art/wp-content/uploads/2023/07/Guido-Sarli_fresco.art11-819x1024.jpg?ssl=1)

![](https://i0.wp.com/fresco.art/wp-content/uploads/2023/07/Guido-Sarli_fresco.art8_-819x1024.jpg?ssl=1)

![](https://i1.wp.com/fresco.art/wp-content/uploads/2023/07/Guido-Sarli_fresco.art6_-1024x683.jpg?ssl=1)

---

#### **OBJETO ARTÍSTICO
***Cuando la poesía visual prima sobre la utilidad*

Desde sus comienzos el oficio artesanal del vidrio ha tenido mucha importancia en los objetos de la vida cotidiana. **El diseño contemporáneo unido con los procesos artesanales tradicionales contribuye a reinventar y revitalizar los objeto**s, dotándolos de identidad, sostenibilidad y diferenciación. En la actualidad existe un movimiento artístico de alta artesanía que apuesta por diseñar piezas que evoquen **pura poesía** en el oficio artesano del vidrio soplado, donde la pieza artística cobra un papel fundamental por sobre su utilidad

#### **[Aire, fuego e intuición.](https://fresco.art/talleres/justine-menard/)
Escultura contemporánea en vidrio con [Justine Menard](https://www.instagram.com/justinemenard_/)**
[23 de septiembre](https://fresco.art/talleres/justine-menard/)[, BARCELONA.](https://fresco.art/talleres/justine-menard/)
1 día | 8 hs

[Ver más](https://fresco.art/talleres/justine-menard/)

**Aforo limitado. Consúltanos por tu plaza a [info@fresco.art](mailto:info@fresco.art)**

El soplado de vidrio es una técnica que permanece intacta desde el Medioevo. Qué lujo poder experimentar esta práctica milenaria desde un lenguaje ultra contemporáneo, como lo es el de Justine Menard! Inspiradas en **ritmos de la naturaleza**y en **formas del Barroco** experimentaremos las técnicas de soplado y vidrio sólido creando mini piezas como medio para estudiar el material y realizar bocetos para luego diseñar esculturas de mayor tamaño. Una oportunidad increíble para diseñar piezas originales y disfrutar del proceso creativo en un ambiente de creación contemporánea. **Te llevarás a casa tu set de esculturas, objetos y joyas** 💎 **Incluye todos los materiales.**

![](https://i0.wp.com/fresco.art/wp-content/uploads/2023/07/Justine-Menard-576x1024.jpg?ssl=1)

![](https://i1.wp.com/fresco.art/wp-content/uploads/2023/07/Justine_Menard_fresco.art4_-1024x768.jpg?ssl=1)

![](https://i0.wp.com/fresco.art/wp-content/uploads/2023/07/Justine_Menard_fresco.art2_-819x1024.jpg?ssl=1)

![](https://i0.wp.com/fresco.art/wp-content/uploads/2023/07/Justine-Menard_fresco.art_-581x1024.png?ssl=1)

![](https://i2.wp.com/fresco.art/wp-content/uploads/2023/07/Justine_Menard_fresco.art11-1024x1024.jpg?ssl=1)

>

**«Siento que crear es una conversación entre tres elementos: estás tú y tus ganas de hacer algo; el material, que tiene su propio pasado; y luego, está la creación en sí misma, que nace de los dos primeros: la fusión entre tú y el material. Este tercer elemento siempre está ahí esperando ser encarnado en algo.» **

**Justine Menard.**

---

**Referencias porque sí**

Popurrí de artistas:

![](https://fresco.art/wp-content/uploads/2023/08/315301969_3345552425689948_928050386328203834_n-881x1024.jpg)

[HEIDI UKKONEN](https://www.instagram.com/ukkon/)

![](https://fresco.art/wp-content/uploads/2023/08/357799838_18014652052632321_1225167378631604002_n-1024x1021.jpg)

[MATÍAS SANCHEZ](https://www.instagram.com/matiassanchezmartin/)

![](https://fresco.art/wp-content/uploads/2023/08/287698286_988450705186455_8389484554871487793_n-1024x1024.jpg)

[THEO FIRMO](https://www.instagram.com/theofirmo/)

![](https://fresco.art/wp-content/uploads/2023/08/277083003_178499017833525_6653165382754451972_n-819x1024.jpg)

[XAVI CEERRE](https://www.instagram.com/xaviceerre/)

**BONUS DE EXPOS, PODCAST, MÚSICA, PELIS Y DOCUMENTALES**

**Expos:**
[André Butzer en Museo Thyssen Madrid](https://www.museothyssen.org/exposiciones/andre-butzer)
[Juan Muñoz en la Hora violeta | CA2M](https://ca2m.org/exposiciones/juan-munoz-en-la-hora-violeta)
[La imagen humana: Arte, identidades y simbolismo | CaixaForum](https://caixaforum.org/es/barcelona/p/la-imagen-humana_a88205544)
[Madrid: Crónica creativa de los 80 | Fundación Canal](https://www.fundacioncanal.com/exposiciones/madrid-cronica-creativa-de-los-80/)

**Cultura general, actualidad, arte contemporáneo y literatura:**
[Podcast «Venecia» | La Casa Encendida](https://soundcloud.com/lacasaencendida/sets/venecia) by [@](https://www.instagram.com/jaimeymanuela_currators/)[jaimeymanuela_currators](https://www.instagram.com/jaimeymanuela_currators/#)
[Podcast «Deforme Semanal Ideal Total» | Radio Primavera Sound by Isa Calderón y Lucía Lijtmaer ](https://open.spotify.com/show/0TCJ4VZKU6YFJjxpl0oHNN?si=b6f6d242b97d4a2a)

**Pelis y documentales:**
[Neo Rauch: Compañeros y acompañantes](https://youtu.be/aJUzrysoLbA)
[El misterio de Picasso](https://vimeo.com/335671350)

**Música:**
He creado [una playlist](https://open.spotify.com/playlist/3TLrgmapTkziXcAOhNQxVf?si=f786f02528974e06) para que te acompañe en tus momentos de creación o introspección.

---

##### ****ASESORAMIENTO PARA ARTISTAS**
**Mentorías personalizadas con artistas contemporáneos

**Recuerda que si necesitas apoyo artístico, exponer tu obra a la crítica y profesionalizar tu visión dentro del mundo del arte actual, organizamos sesiones personalizadas con artistas contemporáneos. Escríbenos a [mentorias@fresco.art](http://mentorias@fresco.art/) y te diseñamos una propuesta*poesía visual prima sobre la utilidad*

![](https://fresco.art/wp-content/uploads/2023/08/2-1024x1024.jpg)

![](https://fresco.art/wp-content/uploads/2022/11/Taller-fresco-Los-Bravu-12-scaled-e1687273135395-1024x660.jpg)

![](https://fresco.art/wp-content/uploads/2023/08/1-1024x1024.jpg)

---

##### ****NUESTRA TIENDA****

---

##### ****HECHO CON **🖤******

##### *Gracias por haber llegado hasta aquí.*

* Este contenido está curado y creado especialmente para tratar ciertos temas del arte que nos inquietan y que habéis manifestado a través de nuestras redes, en respuesta al llamamiento de Enchastre que hemos hecho. Puedes sugerirnos temas al siguiente correo: [enchastre@fresco.art]*

[Nos vemos muy pronto]
