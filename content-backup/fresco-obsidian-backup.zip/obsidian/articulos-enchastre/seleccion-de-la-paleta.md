---
title: "Selección de la paleta"
wordpress_id: 12513
content_type: post
status: "publish"
published_at: "2022-06-29T15:57:17"
modified_at: "2022-08-01T10:01:01"
slug: "seleccion-de-la-paleta"
source_url: "https://fresco.art/seleccion-de-la-paleta/"
categories: ["Enchastre"]
tags: ["aprender a pintar", "arte contemporáneo", "artista", "colores", "estudio de color", "madrid", "paleta", "pintura", "talleres de pintura"]
---
# Selección de la paleta

Entrega 2 – Enchastre:

![](https://fresco.art/wp-content/uploads/2022/06/Header-1024x400.jpg)

**Sobre el color como instrumento mental, la identidad del artista, cómo encontrar nuestra paleta y ¡mucho más! **

*En fresco. nos seduce ese velo de misterio que hay detrás de cada manifestación artística. Nos conmueve la generosidad y valentía de lxs artistas al compartir su mundo interior, para que las personas conozcan otras maneras de percibir la realidad. Vemos a la creación como un acto de amor profundo y por eso estamos aquí para ayudar a potenciarla.

Además notamos que hay una necesidad imperiosa de abordar algunos temas del mundo de la creación, particularmente de los procesos pictóricos. Por ello utilizaremos este medio para profundizar en diferentes temas.
*

![](https://fresco.art/wp-content/uploads/2022/06/2-1024x499.jpg)

![](https://fresco.art/wp-content/uploads/2022/06/Javier-Ruiz-fresco.art_-1024x752.jpeg)

*«Se volvió a hacer de noche mientras dormíamos»*  Óleo sobre lienzo de [Javier Ruiz](https://art.us5.list-manage.com/track/click?u=e9d310075dc515b605aaa6985&id=b7164818d0&e=c0be9838b8)

#### **El color como instrumento mental**

El llamado **imaginario colectivo** se construye así: aparece una idea, cobra forma, gusta, empieza a ser usada por las personas, los artistas, los diseñadores y los directores de cine, poco a poco, tal vez porque tiene más posibilidades que otras para sobrevivir, se convierte en un arquetipo compartido.

Todas las sociedades han formulado desde siempre sistemas simbólicos en los que reconocerse y en los que el color ha tenido un papel fundamental: grandes narraciones épicas y religiosas, iconos y figuras a los que encomendarse o tomar como modelo, convenciones morales, nuevas tecnologías y normas de comportamiento.

**Las ideas nacen enfrentándose a problemas reales, no en abstracto.**

Un instrumento mental es una forma de razonar que nos ha sido proporcionado por una situación concreta en la que hemos crecido. Esto no sucede solo en la cabeza del artífice individual, sino que puede ser una circunstancia que concierna a toda una sociedad.

Tal instrumento no debe imaginarse como un filtro que se sitúa entre nosotros y el conocimiento, como si fuera una plancha de vidrio que nos hace ver todo «alterado». Justamente porque está determinado por contingencias históricas y, sobre todo, porque es algo en lo que nos hallamos «inmersos»

**Por estas razones,  el color no es solo una percepción o una cualidad de las cosas, sino una categoría psicológica que existe junto al modo de producirlo, de difundirlo y de representarlo.**

**Guiado por la intuición y la decisión mental de cómo será el prisma de su obra, el artista, a lo largo de su trayectoria, construye  una paleta de colores que lo identifica. **

*Basado en Libro «Cromorama» de Riccardo Falcinelli. Página 344.*

#### **La importancia de estudiar el color**

**En este viaje de encontrar nuestra paleta, es muy recomendable realizar estudios y pruebas de color que nos acercan al clima de lo que queremos pintar o al lenguaje propio que queremos construir.**

Hay muchísimos libros y material disponible sobre la Teoría del Color (van algunos enlaces debajo) por si quieres profundizar más sobre este tema.
Lo cierto es que cada artista realiza los estudios de color que más eficiente encuentra para el material de pintura que utiliza o según su forma de trabajar.

![](https://fresco.art/wp-content/uploads/2022/06/Javier-Ruiz-fresco.art-estudio-881x1024.jpeg)

Estudio de color de [Javier Ruiz](https://art.us5.list-manage.com/track/click?u=e9d310075dc515b605aaa6985&id=2be29ee8a4&e=c0be9838b8), artista de nuestro taller presencial  [«El oficio del pintor: estudio para un Paisaje Surrealista Figurativo»](https://fresco.art/talleres/javier-ruiz-19/)

#### **La necesidad del artista de permanecer**

***Ser reconocido por nuestra obra está dentro de los grandes objetivos de la mayoría de los artistas. Uno de los mayores protagonistas para dejar nuestra huella en el mundo es el color que usamos. ¿Qué tan consciente de ello eres?***

![](https://fresco.art/wp-content/uploads/2022/06/fresco.arte-eschastre-878x1024.jpeg)

*«La idea de ser completamente olvidado me persigue».  *Imagen de [Geloy Concepcion](https://www.instagram.com/geloyconcepcion/), artista visual que habla de las verdades crudas de la vida cotidiana con un tratamiento agridulce magistral. Echa un vistazo en su perfil 🙂

![](https://fresco.art/wp-content/uploads/2022/06/fresco.art-santiago-picatoste-768x1024.jpeg)

Demostración de gestos pictóricos por [Santiago Picatoste](https://art.us5.list-manage.com/track/click?u=e9d310075dc515b605aaa6985&id=97a498e07d&e=c0be9838b8),
en nuestro taller el pasado fin de semana en Madrid.

**«Look de artista»**

Es uno de los conceptos desarrollados por [Santiago Picatoste](https://art.us5.list-manage.com/track/click?u=e9d310075dc515b605aaa6985&id=7c88863129&e=c0be9838b8) en nuestro pasado taller presencial **[«Abstracción figurativa: Masterclass de 5 claves»](https://fresco.art/talleres/santiago-picatoste/),** enero 2022 – Madrid y en nuestro Retiro en Málaga cada primavera y otoño **«[Fábrica de deseos: Jam session en la nave industrial del artista](https://fresco.art/talleres/retiro_malaga/)«**, para invitarnos a todxs los artistas que asistimos a reflexionar sobre el mensaje estético que transmitimos con nuestra obra. Esto abarca desde los colores que utilizamos, la selección del soporte, el tratamiento de la relación de figura/fondo y hasta cómo comunicamos nuestro trabajo al público, ya sea en las redes sociales o a un coleccionista. Si no te has puesto a pensar en ello, te sugiero que lo hagas para profesionalizar más tu obra.

**Y si te quedaste con ganas de participar, escríbenos a info@fresco.art para revivir la siguiente experiencia:**

**Así fue nuestra experiencia en abril 2022. ¡Te esperamos este otoño, últimas plazas!**

#### **El color como instrumento técnico**

**Se puede ampliar la gama de efectos técnicos de una obra mediante contrastes de diferentes tonos.**

Muchas veces hemos escuchado que la pintura es una mentira.
Es posible crear una ilusión de recesión, por ejemplo, a través de la pintura. Pero para ello es necesario entrenar lo que vemos y analizar de qué manera vamos a recrear con la pintura los efectos de la atmósfera y la luz sobre los objetos a representar.

Tanto si el tratamiento es realista, figurativo o abstracto, las formas se describen por medio de líneas y masas de color. El desarrollo del arte occidental ha establecido la opinión general de que ambos elementos tienen la misma importancia en un cuadro: la forma y el color. Normalmente los términos, reglas, criticas y evaluaciones que se aplican a la línea pueden aplicarse también al color.

Este es uno de los factores que hacen que un artista escoja entre las diversas técnicas de pintura óleo, acuarela, temple, pastel, etc., ya que cada método tiene sus propiedades, que le hacen especialmente indicado para determinados efectos.
La exclusión deliberada de un cierto color, o el énfasis también deliberado de un color concreto pueden influir en el efecto total hasta el punto de crear calidades que contribuyan al contenido de la pintura.

Algunas escuelas han considerado tabú el uso de ciertos colores; en el pasado estaba vedado el empleo de los pardos, a causa de la repulsión general por su insistente utilización en el siglo XIX. El uso de negro para obtener variaciones de tono da a la pintura un cierto carácter inconfundible. A algunos pintores les gusta este efecto; otros lo aborrecen hasta el punto de excluir de sus paletas los pigmentos negros, como los impresionistas.

Basado en «El gran libro de la pintura al óleo»

![](https://fresco.art/wp-content/uploads/2022/06/Impresionistas-fresco.art_-1024x826.jpeg)

*«Claude Monet in Argenteuil» — *Édouard Manet, 1874.

**Los impresionistas y el color como lenguaje

*“Una mañana, uno de nosotros se quedó sin el negro y fue el nacimiento del Impresionismo”  ***Renoir

En esta frase, Renoir nos explica con ironía una de las características principales de la pintura de los impresionistas: no utilizan el color negro.  Los artistas de este movimiento no pintan la «naturaleza» sino “cómo percibe el ojo a la naturaleza».  Sostenían que no vemos objetos particulares, cada uno con su propio color, sino una mezcla de tonos que se combinan en nuestra vista”

Es el ojo humano es el que mezcla los colores y no la paleta del pintor.
El artista es el ojo.

Los impresionistas yuxtaponen (ponen una junto a otra) pinceladas de pigmentos puros. Cuando el espectador se aleja, esas pinceladas se “funden” y generan el color que percibimos. Lo que ellos notan, en ese sentido, es que el negro no existe como tal en la naturaleza. Las sombras nunca son negras, sino coloreadas.

**Un poco de contexto de la época:**

El siglo XIX fue un período de grandes cambios para los pintores.  Las innovaciones del color que trajo la era industrial impulsaron la gran revolución creativa en la pintura que dio origen al movimiento impresionista.  Estos descubrimientos contribuyeron en su interés de captar la luz visible y sus efectos sobre la superficie de los objetos.

Como estaban muy interesados ​​en la luz, estos artistas dejaron el estudio y comenzaron a pintar en plena calle o en escenarios naturales. Debido a que gran parte de sus obras en espacios exteriores, pintaban rápidamente para capturar los efectos de la luz cambiante del día. Esto resultó en un trabajo con pinceladas sueltas o desordenadas que parecían sin terminar en comparación con las obras tradicionales.

Algunos de lxs artistas más famosos asociados con el movimiento impresionista son: *Claude Monet, Eugene Boudin, Camille Pissarro, Alfred Sisley, Édouard Manet, Edgar Degas, Paul Cézanne, Auguste Renoir, Berthe Morisot y Mary Cassatt.*
Basado en «[Los colores de los impresionistas y sus obras](https://art.us5.list-manage.com/track/click?u=e9d310075dc515b605aaa6985&id=00dc5aee93&e=c0be9838b8)«

#### **¿Cómo encontrar nuestra paleta?**

**Además de todo lo que fuimos profundizando, aquí algunas guías que pueden orientarte a seleccionar los colores de tu obra by [Jazzy Dope](https://art.us5.list-manage.com/track/click?u=e9d310075dc515b605aaa6985&id=3661901223&e=c0be9838b8)**

![](https://fresco.art/wp-content/uploads/2022/06/jazzy-dope-play.fresco.art_-1024x768.jpeg)

Fragmento del Curso Online con [Jazzy Dope](https://art.us5.list-manage.com/track/click?u=e9d310075dc515b605aaa6985&id=beb628ae26&e=c0be9838b8) [«El retrato como excusa para contar historias»](https://art.us5.list-manage.com/track/click?u=e9d310075dc515b605aaa6985&id=007a01226a&e=c0be9838b8)  ya disponible!

**Recomendación del artista**

En nuestro curso online, Jazzy ha dedicado mucho tiempo a compartir cómo selecciona él su paleta de óleos y por qué.

En líneas generales recomienda que empieces por una paleta básica a la que le vayas añadiendo los tonos que más te atraigan. Sugiere no comprar los colores ya fabricados, porque dejan un acabado muy falso.

En general todos los colores dependen de la luz y el ambiente, y por ello tenemos que aprender a mezclarlos.  En nuestro curso online Jazzy te explica cómo mezclar los colores para lograr una gama amplia que permita contar los puntos máximos de luz y sombra, darle vivacidad a la obra. Además. explica cómo aplicar la pintura por planos, creando un efecto visual geométrico, rompiendo la forma, yendo más allá de los límites de la realidad.

![](https://fresco.art/wp-content/uploads/2022/06/jazzy-dope-play.fresco.art-2-1024x576.jpeg)

>

**«Lo importante es conocer bien tu paleta, trabajar con ella y cuando estés seguro con ella, integrar ciertos matices que te atraigan»**
Julián Diez, mejor conocido como Jazzy Dope.

![](https://fresco.art/wp-content/uploads/2022/06/jazzy-dope-play.fresco.art-3-1024x768.jpeg)

**La Paleta de Jazzy Dope**

**Óleos:**
Blanco Titánium  – Titán o Rembrandt.
Amarillo Cadmio Limón  – Titán o Winsor & Newton.
Rojo de Cadmio – Titán
Rojo Escarlata  – Winsor & Newton.
Rojo Laca de Garanza – Rembrandt.
Azul Cobalto  – Old Holland.
Azul Ultramar – Winsor and Newton

**Médiums (para mezclar con la pintura):**
Liquin impasto – Winsor & Newton.
Disolvente – cualquier marca

**Saber ver, componer e interpretar**

Además de la selección del color, en el curso Jazzy te enseña a observar los elementos que componen  tu obra, para que aprendas a interpretar lo que te rodea y mostrarle al mundo tal cual ves.

Durante todo el curso Jazzy nos aporta sus herramientas para que nos inspiremos a crear en base a nuestra propia voz. Nos muestra sus experimentos con diferentes materiales en sus libretas de artista, vemos la importancia de dibujar antes de pintar, vemos su relación con el dibujo y la pintura en una sesión entera de demostración y finalmente nos aporta tips y consejos para nuestro crecimiento como artista, en el camino hacia la búsqueda de nuestro lenguaje propio.

#### **Artistas reconocidos por el color**

Antes de cerrar este artículo, veamos dos maestros de la pintura reconocidos por cómo han trabajado el color y una selección especial de dos artistas actuales, destacados también (a mi criterio) por su lenguaje cromático.

![](https://fresco.art/wp-content/uploads/2022/06/Gauguin-fresco.art_-1024x846.jpeg)

Colores vivos, discordantes, para crear un fuerte impacto emocional, de Gauguin.** **«Mata Mua», Museo Thyssen-Bornemisza.

![](https://fresco.art/wp-content/uploads/2022/06/Rembrandt-fresco.art_-1024x845.jpeg)

Claroscuros e impastos plenos de Rembrandt. «The Anatomy Lesson of Dr Nicolaes Tulp»

![](https://fresco.art/wp-content/uploads/2022/06/Jenna-Gribbon-fresco.art_-1024x846.jpeg)

El contraste cromático de [Jenna Gribbon](https://art.us5.list-manage.com/track/click?u=e9d310075dc515b605aaa6985&id=80822ce9b5&e=c0be9838b8) «What am I doing here? I should ask you the same» 2022

![](https://fresco.art/wp-content/uploads/2022/06/Adrian-Ghenie-fresco.art_.jpeg)

Efectos pictóricos de [Adrian Ghenie](https://art.us5.list-manage.com/track/click?u=e9d310075dc515b605aaa6985&id=77317a4f45&e=c0be9838b8) «Rest during the flight into Egypt» 2016

**Recursos**

**Aquí algunos enlaces de libros y otras fuentes que he consultado para inspirarme en este artículo:**
[Gauguin, Taschen](https://art.us5.list-manage.com/track/click?u=e9d310075dc515b605aaa6985&id=0d3b92e9c6&e=c0be9838b8)
[El gran libro de la pintura al óleo](https://art.us5.list-manage.com/track/click?u=e9d310075dc515b605aaa6985&id=15e2fc64e5&e=c0be9838b8)
[Ebook Biblioteca Reina Sofía](https://art.us5.list-manage.com/track/click?u=e9d310075dc515b605aaa6985&id=7e3efa6d39&e=c0be9838b8)
[Libro  «Cromorama» de Riccardo Falcinelli.](https://art.us5.list-manage.com/track/click?u=e9d310075dc515b605aaa6985&id=7deb167951&e=c0be9838b8)
[Teoría del color](https://art.us5.list-manage.com/track/click?u=e9d310075dc515b605aaa6985&id=74c4a4c968&e=c0be9838b8)
Colores de los impresionistas

**Este contenido está curado y creado especialmente**
*Gracias por haber llegado hasta aquí. *
*Este contenido está creado para tratar ciertos temas del arte que nos inquietan y que habéis manifestado a través de nuestras redes, en respuesta al llamamiento de Enchastre que hemos hecho.*

***Si te quedaron dudas, quieres aportar un punto de vista distinto o sugerir un nuevo tema a abordar, puedes escribirme*** ***a enchastre@fresco.art ***
