---
title: "Pintura y otras artes. ¿Cómo evocar la belleza oculta?"
wordpress_id: 12707
content_type: post
status: "publish"
published_at: "2022-08-13T22:13:26"
modified_at: "2022-08-15T17:51:39"
slug: "pintura-y-otras-artes-como-evocar-la-belleza-oculta"
source_url: "https://fresco.art/pintura-y-otras-artes-como-evocar-la-belleza-oculta/"
categories: ["Enchastre"]
tags: ["Arte performático", "Carlota Guerrero", "Gloria Martín", "Herni Matisse", "Mercedes Bellido", "Nicolas Romero Escalada", "Performance", "arte contemporáneo", "artista", "artistóteles", "bellas artes", "belleza", "colores", "danza", "escultura", "estudio", "expresión corporal", "fotografía", "identidad de artista", "ilustración", "lenguaje visual", "madrid", "paleta", "pintura", "pintura al óleo", "taller", "talleres de pintura", "teatro", "texturas"]
---
# Pintura y otras artes. ¿Cómo evocar la belleza oculta?

Entrega 4 – Enchastre:

![](https://fresco.art/wp-content/uploads/2022/06/Header-1024x400.jpg)

Sobre descubrir el lenguaje poético de todas las artes. ¿Cómo evocamos la belleza oculta?

*En fresco. nos seduce ese velo de misterio que hay detrás de cada manifestación artística. Nos conmueve la generosidad y valentía de lxs artistas al compartir su mundo interior, para que las personas conozcan otras maneras de percibir la realidad. Vemos a la creación como un acto de amor profundo y por eso estamos aquí para ayudar a potenciarla.

Además notamos que hay una necesidad imperiosa de abordar algunos temas del mundo de la creación, particularmente de los procesos pictóricos. Por ello utilizaremos este medio para profundizar en diferentes temas.
*
Editorial e investigación by** [Brenda Ranieri](https://www.instagram.com/brendaranieri.studio/).**

![](https://fresco.art/wp-content/uploads/2022/08/4-1024x499.jpg)

[

![](https://fresco.art/wp-content/uploads/2022/08/Mercedes_Bellido_fresco.art_talleres_Madrid-1024x690.jpg)

](https://fresco.art/talleres/mercedes_bellido/)

Detalle de obra de Mercedes Bellido

***«Rotura y calimorfas»,** acrílico sobre papel, detalle díptico. De [**Mercedes Bellido**](https://fresco.art/talleres/mercedes_bellido/),* artista de nuestro próximo en Madrid, 1 y 2 de octubre: «**[Paisajes oníricos. Evocando la belleza oculta](https://fresco.art/talleres/mercedes_bellido/)**» **¡Últimas plazas!**

>

****«El proceso lógico es rebelarse contra lo más actual y presente, lo más reaccionario es retomar las prácticas tradicionales y darles otra vuelta más. Me parece lo más punk trabajar con las manos ahora mismo»****

Mercedes Bellido

Las artes son un fenómeno social, un medio de comunicación, una necesidad del ser humano de expresarse y comunicarse mediante formas, colores, sonidos y movimientos; el arte es un producto o acto creativo. En este especial he seleccionado algunas de las artes que más me inspiran en este momento: como la danza, el teatro, la fotografía, la pintura y la escultura, para abordar un hilo conductor que me inquieta:

### **¿Cómo evocar la belleza oculta?**

**«La finalidad del arte es dar cuerpo a la esencia secreta de las cosas, no el copiar su apariencia» **según Aristóteles. Esta línea de pensamiento se puede aplicar a todo tipo de expresión. Por ejemplo, hace tiempo vengo pensando en **el lenguaje del cuerpo y su sabiduría**, y cuánto podríamos resolver si lo escucháramos un poco más.

![](https://fresco.art/wp-content/uploads/2022/08/Damien-Jalet_2-832x1024.jpg)

Imagen de[**Damien Jalet**](https://www.instagram.com/sirjoancornella/), (Bélgica,1976) es un coreógrafo y bailarín independiente belga/ francés. Echa un vistazo en su perfil 🙂

###### **Arte en movimiento**

El  lenguaje corporal en movimiento es efímero, pasa y luego se va. Pero ¿Qué pasa si lo materializamos con otro tipo de arte, si inmortalizamos ese instante dándole una nueva vida desde otra óptica creativa? Es lo que pienso cuando veo el trabajo de artistas como [Carlota Guerrero](https://www.instagram.com/carlota_guerrero/), que en ocasiones usa el cuerpo como excusa para contar lo etéreo, lo natural, el movimiento, la belleza oculta transmitida en una fotografía.

![](https://fresco.art/wp-content/uploads/2022/08/Carlota_Guerrero-1024x768.jpg)

Foto by Carlota Guerrero.

**Se vieneeeeee próximamente:**

#### Taller pintura y expresión corporal:
Sevilla, noviembre 2022

*Una oportunidad única de llevar hasta el límite el lenguaje poético del cuerpo, bailando y pintando. Fusionar el cuerpo y la pintura, el movimiento y el gesto pictórico. **En breve lo anunciaremos en redes y web, stay tuned!****** Será una experiencia brutal!***

****[info@fresco.art](mailto:info@fresco.art)** si quieres recibir info.**

---

### **Performance. ¿Qué es y cómo se relaciona con la pintura?**

**Performance art (o arte de acción, arte en vivo)** es una disciplina artística creada a través de acciones realizadas por el artista u otros participantes, pudiendo ser en vivo, documentadas, espontáneas o escritas, presentada a un público dentro de un contexto expositivo.​  Tradicionalmente **involucra cuatro elementos básicos: el tiempo, el espacio, el cuerpo o la presencia del artista en un medio, y la relación entre el creador y el público**. ​ Su objetivo es generar una reacción, en ocasiones con la ayuda de la improvisación y el sentido de la estética. La temática suele estar ligada a procesos vitales del propio artista, a la necesidad de denuncia o crítica social y con un espíritu de transformación.

Los principales precursores y pioneros del arte de la performance son artistas como Carolee Schneemann, Marina Abramovic, Ana Mendieta, Chris Burden, ​ Hermann Nitsch, Joseph Beuys, Nam June Paik o Vito Acconci, y los máximos exponentes en la actualidad, artistas como Tania Bruguera, Abel Azcona, Regina José Galindo, Tehching Hsieh, Marta Minujín o Piotr Pavlenski. Disciplina claramente ligada al happening,  al arte corporal y, en general, al arte conceptual.

#### Lo teatral del objeto:
¿Sabías que los objetos también pueden ser parte de una Performance?

En movimientos como el **Surrealismo** o el **Dadaísmo** el diseño y los objetos cotidianos fueron una gran fuente de inspiración y tuvieron un papel crucial en su evolución. Artistas como **Man Ray, Salvador Dalí, Marcel Duchamp,Joan Miró, **entre otros, se sintieron atraídos por el potencial de combinar objetos de la vida cotidiana para crear nuevas formas. Su trabajo se basa en la idea surrealista de que las combinaciones inesperadas pueden tener un efecto inquietante.

![](https://fresco.art/wp-content/uploads/2022/08/f.elconfidencial.com_original_d68_97e_495_d6897e4951654f698d33fa0b0c3c65a4-768x1024.jpg)

Escultura ‘Dona i ocell’, Joan Miró. 1967, Barcelona.

Esta etapa de **Joan Miró **estuvo marcada por la idea de evolucionar e ir más allá de la pintura (o «asesinato de la pintura», como lo llamaría él mismo). Consiste en la creación de obras escultóricas, recreando figuras como un collage en tres dimensiones formado a partir de objetos fundidos en bronce, pensando como una forma de poesía visual.

#### Objetos para analizar la cultura pop

El imaginario colectivo está repleto de símbolos que nos hablan de la relación de los seres humanos con los objetos, con lo que consumimos: desde elementos de nuestra vida cotidiana o memes de Internet. El pintor **[Nicolás Romero Escalada](https://www.instagram.com/eversiempre/)** **(eversiempre)** se inspira en esto para hacer análisis antropológicos y construir en base a ello naturalezas muertas llenas de simbología, con una calidad pictórica increíble.
Su trabajo mantiene un equilibrio elegante entre la denuncia y el humor, la cultura pop y la nostalgia. **No podemos estar más felices de contar con él en nuestro próximo taller, el [17 y 18 de septiembre en Madrid.](https://fresco.art/talleres/nicolas_romero_escalada/)**

>

**“Utilizo esos elementos porque creo que actualmente nos describimos políticamente a través del consumo, ya que vivimos en un mundo capitalista y lo que consumimos nos representa. Actualmente, mis obras las empiezo como investigaciones antropológicas. Estos objetos, plasmados todos juntos, representan la ausencia humana, pero a su vez (en contradicción) representan enteramente al humano.”**

Nicolás Romero Escalada

[

![](https://fresco.art/wp-content/uploads/2022/08/Nicolas_Romero_Escalada_fresco.art_Madrid-822x1024.jpg)

](https://fresco.art/talleres/nicolas_romero_escalada/)

[Nicolás Romero Escalada](https://fresco.art/talleres/nicolas_romero_escalada/) pintor de nuestro curso del 17 y 18 de septiembre, en Madrid.

#### «[Naturalezas Muertas como medio para representar la cultura pop.](https://fresco.art/pablomerchante)«

Taller intensivo 17 y 18 de septiembre, Madrid.

Será un fin de semana de trabajo de campo, arte performático y lenguaje pictórico. Recolectaremos símbolos del imaginario colectivo (objetos que consumimos, memes, simbología, etc) y objetos de nuestra vida,  para interpretar Naturalezas Muertas que nos sirvan de puente para dialogar sobre lo que nos inquieta. Instalaremos una clínica de investigación antropológica partiendo de los símbolos que recolectaremos en un recorrido por el barrio del taller, Carabanchel, combinándolos con objetos de nuestra vida cotidiana y de la cultura popular.

Descubriremos el proceso creativo del artista, desde la investigación hasta la implementación pictórica, y lo aplicaremos a nuestro lenguaje personal.

Construiremos una instalación de Naturaleza Muerta que utilizaremos como modelo del natural, para hacer estudios y apuntes que nos sirva de inspiración para futuros proyectos personales. Interpretando escenografías de la cultura popular, devolveremos esos objetos al territorio público desde la apertura al diálogo. Plantearemos nuestras preguntas a través del gesto pictórico.

¡Últimas plazas! Apúntate [**aquí.**](https://fresco.art/talleres/nicolas_romero_escalada/)

---

![](https://fresco.art/wp-content/uploads/2022/08/the-pink-studio-1.jpgLarge-1.jpg)

«The pink studio», Henri Matisse, 1911.

#### **¿Alguna vez pensaste en tu estudio como una obra performática?**

El artista hace de su espacio de trabajo su mundo, su propio universo, donde muchas veces lo cotidiano y lo artístico se desdibuja. A menudo la propia obra nos habla del lugar en donde fue creada, por su tamaño, materiales o tratamiento. El taller del artista se convierte en un diario de procesos creativos, alquimia, enfoques y oficio.

Algunos pintores eligen que el estudio sea el tema a representar en su trabajo. Si lo pensamos, tiene mucho sentido: es un espacio donde el acto escénico se da prácticamente natural y donde seguramente todo podría inspirarnos para ser pintado.
Además, pintando su mismo oficio de la pintura, el artista se expone a la contemplación del público. Rompe con ese velo de misterio, pasando de la experiencia privada al espacio público.

Henri Matisse’s The Red Studio (L’atelier): The Journey of a Painting. MoMa.

#### Fin de semana metapictórico

De la mano de la reconocida pintora española, [Gloria Martín](https://fresco.art/talleres/gloria_martin/), en uno de nuestros talleres de octubre 2022, hablaremos de pintura con nuestra pintura. Aprendiendo sobre composición, perspectiva, geometría, texturas y las leyes de trampantojo, pintaremos el lenguaje del oficio**. **mientras estamos inmersos en él. Un acto performático total.
** [21 al 23 de octubre en Madrid](https://fresco.art/talleres/gloria_martin/), **¡Últimas plazas!

>

**“Me fascina toda esa estética del enseñar, de la pedagogía del arte, la cocina de las técnicas pictóricas, que a veces tiene más de receta que de otra cosa. Al fin y al cabo, estoy hablando de algo que tiene que ver con mi día a día; y como cada proyecto supone una oportunidad para investigar, reviso tratados de pintura, de dibujo, de perspectiva…”**

Gloria Martín

[

![](https://fresco.art/wp-content/uploads/2022/08/Gloria_Martin_fresco.art_taller_pintura_Madrid_2-1024x847.jpg)

](https://fresco.art/talleres/gloria_martin/)

Obra de [Gloria Martín](https://fresco.art/talleres/gloria_martin/), pintora de nuestro taller de pintura del 21 al 23 de octubre, Madrid.

#### «[Develando los artificios de la pintura, desde la pintura](https://fresco.art/talleres/gloria_martin/)«

Taller intensivo 21 al 23 de octubre, Madrid.

Como un ejercicio para entrenar la mirada, nos haremos hipersensibles al entorno que nos rodea dentro del taller para poder representar el espacio que habitamos y reflexionar sobre ello.Pintaremos del natural los rincones de nuestro atelier de fin de semana, en una experiencia casi teatral, performática. Crearemos un ambiente súper inspirador, de retroalimentación entre artistas, guiados por ejercicios de la mentora. Una oportunidad imperdible de entrar en contacto con los aprendizajes de estudio de una pintora tan talentosa y sensible como Gloria Martín. Además, el primer día tendremos la oportunidad de visitar en exclusiva su exposición individual que tendrá lugar en la **Galería Silvestre**, Madrid.

¡Últimas plazas! Apúntate [**aquí.**](https://fresco.art/talleres/gloria_martin/)

---

Entonces. **¿Cómo evocar la belleza oculta?** Aún no lo sé, pero intuyo que tendrá que ver con prestar atención a lo que nos rodea, darle la vuelta, consumir diferente tipo de expresiones artísticas (cine, teatro, fotografía, pintura, escultura, etc), ver mucho arte, hablar con artistas, apoyar al artista local, compartir lo que nos gusta.

**La inspiración es contagiosa, y la necesitamos.**

---

**Referencias porque sí**

***Antes de cerrar este artículo, os dejo un popurrí de algunos artistas contemporáneos que me han estado inspirando en el último tiempo***:

![](https://fresco.art/wp-content/uploads/2022/08/Eva-Fabregas-1024x1024.jpg)

[Eva Fàbregas](https://www.instagram.com/eva_fabregas/)

![](https://fresco.art/wp-content/uploads/2022/08/Benedikt-Hipp-831x1024.jpg)

[Benedikt Hipp](https://www.instagram.com/benedikthipp/)

![](https://fresco.art/wp-content/uploads/2022/08/Julia-Santaolalla-1024x1024.jpg)

[J](https://www.google.com/search?q=hurvin+anderson&hl=en&source=lnms&tbm=isch&sa=X&ved=2ahUKEwjb-qubsPD2AhWmRPEDHSByA6IQ_AUoAXoECAIQAw&cshid=1648730838144476&biw=1440&bih=661&dpr=1)[ulia Santaolalla](https://www.instagram.com/juliasantaolalla/)

![](https://fresco.art/wp-content/uploads/2022/08/Ernesto-Artillo-851x1024.jpg)

[Ernesto Artillo](https://www.instagram.com/ernestoartillo/)

**Recursos**

**Aquí algunos enlaces de libros y otras fuentes que he consultado para inspirarme en este artículo:**
How to see | Especial entrevistas e investigaciones by MoMa (YouTube)
How art become active? | 5 episodios  by Tate Museam (TateShots)
Henri Matisse’s The Red Studio (L’atelier): The Journey of a Painting. MoMa
Exposición «Objetos de deseo. Surrealismo y diseño. 1924-2020
Biblioteca Reina Sofía

**Este contenido está curado y creado especialmente**
*Gracias por haber llegado hasta aquí. *
*Este contenido está creado para tratar ciertos temas del arte que nos inquietan y que habéis manifestado a través de nuestras redes, en respuesta al llamamiento de Enchastre que hemos hecho.*

***Si te quedaron dudas, quieres aportar un punto de vista distinto o sugerir un nuevo tema a abordar, puedes escribirme*** ***a enchastre@fresco.art ***
